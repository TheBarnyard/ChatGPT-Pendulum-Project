"""
The planned triple swing-up as a controller for this simulator (no learning involved).

    python plan_expert.py                  # 20 test episodes from the normal hanging starts, prints the result
    python watch.py --task triple_swingup --plan      # watch it live
    python record.py --task triple_swingup --plan     # mp4

What it is (the team's own swing-up method, PUC Math/Triple/04_swing_up.md, on this folder's model):
  1. model/triple_swingup_plan.json: a 4.0 s cart motion that takes the three arms from hanging to upright,
     found by trajectory optimisation (model/make_plan.py; track 0.40 m, speed 1.2 m/s, accel 6.3 m/s^2 used);
  2. while the plan runs, a time-varying LQR pulls the arms back onto the plan (one gain row per 10 ms,
     the plan point is chosen by the clock: episode time, plus the start point for plan-start episodes);
  3. after the plan, the upright LQR holds the balance.
(Tried 2026-11-15 and dropped: choosing the plan point from the state instead of the clock, "nearest of the
next 0..3 points". It passed only 13 of 20 episodes; the clock version passes 20 of 20.)
The controller reads the true simulator state (cart x, v and the three absolute arm angles and rates), the
same numbers the policy observes. Its output is the env's action: the cart speed command / max speed.

imitate.py teaches a neural policy to copy this controller; train.py --plan-start-prob starts RL training
episodes along the plan.
"""
import json, sys
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parent


def load_plan(model_dir='model', kind='triple'):
    """(Z [N+1, 8], a [N+1], dt, doc). Z rows are [th1, w1, th2, w2, th3, w3, x, v], absolute angles from upright."""
    path = ROOT / model_dir / f'{kind}_swingup_plan.json'
    if not path.exists():
        raise FileNotFoundError(f'{path} is missing. Make it with:  pip install casadi ;  python model/make_plan.py')
    doc = json.load(open(path))
    return np.array(doc['z'], float), np.array(doc['a'], float), float(doc['dt']), doc


def plan_qpos_qvel(z):
    """Plan state -> MuJoCo qpos, qvel (joint angles are relative, the plan's are absolute)."""
    return (np.array([z[6], z[0], z[2] - z[0], z[4] - z[2]]), np.array([z[7], z[1], z[3] - z[1], z[5] - z[3]]))


class PlanExpert:
    """Plan + time-varying LQR + balance LQR. predict(obs) reads the env it was given (like watch.py's LQR)."""

    def __init__(self, env, angle_deg=5.0, rate_deg_s=120.0, cart_m=0.25, cart_speed=0.3, accel_cost=5.0):
        sys.path.insert(0, str(ROOT / env.cfg['model']))
        import nlink_cart as nl
        self.nl, self.env, self.Ts = nl, env, env.cfg['ctrl_dt']
        self.Z, self.a, dt, self.doc = load_plan(env.cfg['model'], env.kind)
        if abs(dt - self.Ts) > 1e-9:
            raise ValueError('plan time step differs from the control step')
        self.N = len(self.Z) - 1
        P = json.load(open(ROOT / env.cfg['model'] / 'params.json'))[env.kind]
        if 'model_arms' in self.doc and json.dumps(self.doc['model_arms']) != json.dumps(P['arms']):
            print('WARNING: the plan was made for other arm values than model/params.json. '
                  'Re-make it:  python model/make_plan.py', flush=True)
        rig = nl.Rig([nl.Link(a['mass'], a['com_along'], a['length'], a['I_swing'], b)
                      for a, b in zip(P['arms'], P['joint_damping'])])
        n = rig.n
        q = []
        for _ in range(n):
            q += [1 / np.radians(angle_deg) ** 2, 1 / np.radians(rate_deg_s) ** 2]
        Q = np.diag(q + [1 / cart_m ** 2, 1 / cart_speed ** 2]); R = np.array([[1 / accel_cost ** 2]])
        Ac, Bc = nl.linear_accel(rig); Ad, Bd = nl.c2d(Ac, Bc, self.Ts)
        Kb, Pb = nl.dlqr(Ad, Bd, Q, R)
        self.K_bal = Kb[0]
        self.K = np.array([k[0] for k in nl.tvlqr(rig, self.Z.T, self.a[:-1], self.Ts, Q, R, Pb)])   # [N, 8]

    def plan_index(self):
        """The plan point for the env's current step: episode time plus the episode's start point."""
        e = self.env
        return e.steps + getattr(e, 'plan_k0', 0)

    def state(self):
        e = self.env; th, w = e.angles()
        return np.array([th[0], w[0], th[1], w[1], th[2], w[2], e.data.qpos[0], e.data.qvel[0]])

    def accel(self, z, k):
        """Wanted cart acceleration at plan step k for state z."""
        if k < self.N:
            return float(self.a[k] - self.K[k] @ (z - self.Z[k]))
        zz = z.copy(); zz[0:6:2] = self.nl.wrap(zz[0:6:2])
        return float(np.clip(-self.K_bal @ zz, -30.0, 30.0))

    def track_error(self, k=None):
        """Largest arm-angle distance from the plan (rad); after the plan, from upright."""
        k = self.plan_index() if k is None else k
        z = self.state()
        if k < self.N:
            return float(np.abs(z[0:6:2] - self.Z[k, 0:6:2]).max())
        return float(np.abs(self.nl.wrap(z[0:6:2])).max())

    def action(self, k=None):
        """Env action (speed command / max speed) for the env's current state at plan step k."""
        e = self.env
        k = self.plan_index() if k is None else k
        z = self.state()
        v = z[7] + self.accel(z, k) * self.Ts
        return float(np.clip(v / e.cfg['max_speed'], -1.0, 1.0))

    def predict(self, obs=None, deterministic=True):
        return np.array([self.action()], dtype=np.float32), None


def main():
    import argparse
    from pendulum_env import CartPendulumEnv
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--episodes', type=int, default=20)
    a, extra = p.parse_known_args()
    env = CartPendulumEnv('triple_swingup'); ex = PlanExpert(env)
    T = env.T; need = T['seconds'] - T.get('swing_s', 4.0); ok = 0
    print(f"Plan: {ex.doc['T']} s, peak track {ex.doc['peak']['track_m']:.2f} m, speed {ex.doc['peak']['speed_m_s']:.2f} m/s, "
          f"accel {ex.doc['peak']['accel_m_s2']:.1f} m/s^2")
    for ep in range(a.episodes):
        obs, _ = env.reset(seed=10_000 + ep); done = False
        while not done:
            obs, r, term, trunc, info = env.step(ex.predict(obs)[0]); done = term or trunc
        good = info['end'] == 'time' and info['best_hold_s'] >= need and info['upright_frac'] >= T.get('pass_up_frac', 0.55)
        ok += good
        print(f"  episode {ep + 1:2d}: return {info['ep_return']:6.1f}  upright {100 * info['upright_frac']:3.0f}%  "
              f"hold {info['best_hold_s']:4.1f} s  cart max {info['max_cart_v']:.2f} m/s, {info['max_cart_a']:.0f} m/s^2  "
              f"{'PASS' if good else 'fail'}")
    print(f'{ok} of {a.episodes} episodes pass the triple swing-up test.')


if __name__ == '__main__':
    main()
