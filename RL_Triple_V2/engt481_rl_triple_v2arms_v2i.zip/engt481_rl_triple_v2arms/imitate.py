"""
Teach a neural policy the planned triple swing-up by imitation (about 10 to 20 minutes on a CPU).

  python imitate.py                                   # -> runs/imit_triple_swingup/best.zip
  python watch.py --run imit_triple_swingup --policy best

Why: four RL runs of 11M steps each never found the catch (they roll the arms round instead). The planned
controller (plan_expert.py: trajectory plan + time-varying LQR + balance LQR) swings this model up every
time, so the policy learns to copy it. In testing (2026-11-15, two seeds) the copy passed 20 of 20 episodes
after 4 and 5 rounds (4 to 6 minutes), score 947 and 946 against the controller's 946.

How (DAgger):
  round 0     the planned controller drives, with a little noise on its commands so the policy also sees
              states next to the plan; every visited state is stored with the command the controller wanted;
  later       in half of the episodes the policy shares the driving with the controller (each step is the
              policy's with 50 to 70 % chance; the controller still says what it would have done in every
              visited state, and that is what is stored), the other half stay with the noisy controller;
              half of all episodes start at a random point of the plan; an episode ends early once the arms
              are far from the plan (labels there are junk);
  each round  the policy network (the same 256x256 SAC actor train.py uses) is fitted to all stored
              state -> command pairs, then tested from the normal hanging starts. The best one is kept.
The saved policy is a normal SAC model: watch.py, record.py and train.py --init-from take it.
Its exploration noise is set small (--std 0.03: it still passes with that noise, at 0.05 only half the time).
RL on top of it is NOT ready: plain SAC fine-tuning (train.py --init-from ... --actor-freeze-steps 30000)
kept the score during the critic warm-up and wrecked the policy within 5,000 steps after it (2026-11-15).
"""
import argparse, json, math, os, sys, time
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parent
RUNS = ROOT / 'runs'
TASK = 'triple_swingup'


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--name', default='imit_triple_swingup')
    p.add_argument('--rounds', type=int, default=12, help='at most this many rounds (default 12)')
    p.add_argument('--episodes', type=int, default=40, help='episodes collected per round')
    p.add_argument('--fit-steps', type=int, default=3000, help='gradient steps per round (batch 4096)')
    p.add_argument('--test-episodes', type=int, default=10)
    p.add_argument('--std', type=float, default=0.03, help='exploration noise the saved policy starts RL with')
    p.add_argument('--device', default='cpu')
    p.add_argument('--threads', type=int, default=max(1, min(6, (os.cpu_count() or 2) // 2)))
    p.add_argument('--seed', type=int, default=0)
    p.add_argument('--no-video', action='store_true')
    a = p.parse_args()

    import torch
    from stable_baselines3.common.vec_env import DummyVecEnv
    from pendulum_env import CartPendulumEnv, make_env, TASKS
    from plan_expert import PlanExpert
    from train import build_model, evaluate, is_solved
    torch.set_num_threads(a.threads); torch.manual_seed(a.seed)
    rng = np.random.default_rng(a.seed)
    run = RUNS / a.name; (run / 'videos').mkdir(parents=True, exist_ok=True)
    env_cfg = dict(model='model', action_mode='velocity', reward='energy')
    json.dump(dict(vars(a), task=TASK, algo='sac', env_cfg=env_cfg, imitation=True), open(run / 'config.json', 'w'), indent=1)
    (RUNS / 'LATEST').write_text(a.name)

    venv = DummyVecEnv([make_env(TASK, 0, a.seed, train_mode=True, **env_cfg)])
    model = build_model('sac', venv, a.device, 8, 512, a.seed)
    actor = model.actor; dev = model.device
    opt = torch.optim.Adam(actor.parameters(), lr=1e-3)
    log_std_target = math.log(a.std)
    env = CartPendulumEnv(TASK, **env_cfg); ex = PlanExpert(env); N = ex.N
    T = TASKS[TASK]; need_hold = T['seconds'] - T.get('swing_s', 4.0); need_up = T.get('pass_up_frac', 0.55)
    print(f'Run folder: {run}\nPlanned controller: {ex.doc["T"]} s plan, peak accel {ex.doc["peak"]["accel_m_s2"]:.1f} m/s^2. '
          f'Up to {a.rounds} rounds of {a.episodes} episodes.', flush=True)

    def student(obs):
        return float(model.predict(obs, deterministic=True)[0][0])

    def rollout(beta, noise, from_plan, seed):
        """One episode. beta = chance per step that the planned controller drives. Returns states, labels."""
        if from_plan:
            obs, _ = env.reset(seed=seed, options=dict(start='plan', plan_k=int(rng.integers(0, N + 100))))
        else:
            obs, _ = env.reset(seed=seed)
        O, A = [], []
        while True:
            a_exp = ex.action()
            O.append(obs); A.append(a_exp)
            act = a_exp if rng.random() < beta else student(obs)
            obs, r, term, trunc, info = env.step([float(np.clip(act + rng.normal(0, noise), -1, 1))])
            if term or trunc or ex.track_error() > (0.6 if ex.plan_index() < N else 0.4):
                return O, A

    def fit(O, A, steps, lr):
        for g in opt.param_groups: g['lr'] = lr
        Ot = torch.as_tensor(np.asarray(O), dtype=torch.float32, device=dev)
        At = torch.as_tensor(np.asarray(A), dtype=torch.float32, device=dev).reshape(-1, 1)
        actor.train()
        for _ in range(steps):
            idx = torch.randint(0, len(Ot), (4096,), device=dev)
            mean, log_std, _ = actor.get_action_dist_params(Ot[idx])
            loss = ((torch.tanh(mean) - At[idx]) ** 2).mean() + 0.01 * ((log_std - log_std_target) ** 2).mean()
            opt.zero_grad(); loss.backward(); opt.step()
        actor.eval()
        with torch.no_grad():
            mean, _, _ = actor.get_action_dist_params(Ot)
            return float(((torch.tanh(mean) - At) ** 2).mean())

    def test(n, seed=10_000):
        res = []
        for ep in range(n):
            obs, _ = env.reset(seed=seed + ep); done = False
            while not done:
                obs, r, term, trunc, info = env.step([student(obs)]); done = term or trunc
            res.append(info)
        ok = sum(1 for i in res if i['end'] == 'time' and i['best_hold_s'] >= need_hold and i['upright_frac'] >= need_up)
        return ok, float(np.mean([i['ep_return'] for i in res])), float(np.max([i['max_cart_a'] for i in res]))

    def save(path):
        with torch.no_grad():
            if getattr(model, 'log_ent_coef', None) is not None:
                model.log_ent_coef.fill_(math.log(0.003))
        model.target_entropy = float(0.5 * math.log(2 * math.pi * math.e) + log_std_target)   # entropy of that noise
        tmp = str(path) + '.tmp.zip'; model.save(tmp); os.replace(tmp, path)

    DO, DA = [], []; t0 = time.time(); best, hist, streak = (-1, -1e9), [], 0
    for rnd in range(a.rounds):
        # the policy never drives alone while collecting: the controller follows the clock, a policy has
        # none, so far from the clock's plan point the labels stop making sense for it (seen 2026-11-15:
        # 10/10 passes at 70 % policy driving, then worse again at 80 to 100 %)
        beta = 1.0 if rnd == 0 else max(0.3, 0.6 - 0.1 * rnd)
        for e in range(a.episodes):
            # half of the later episodes stay with the planned controller under stronger noise
            b, nz = (1.0, 0.03 + 0.05 * rng.random()) if (rnd == 0 or e % 4 >= 2) else (beta, 0.01)
            O, A = rollout(b, nz, from_plan=(e % 2 == 1), seed=1000 * (rnd + 1) + e)
            DO += O; DA += A
        mse = fit(DO, DA, a.fit_steps, 1e-3 if rnd < 3 else 3e-4 if rnd < 8 else 1e-4)
        ok, ret, acc = test(a.test_episodes)
        score = (ok, ret); hist.append(dict(round=rnd, data=len(DO), fit_error=mse, passed=ok, of=a.test_episodes,
                                             mean_return=ret, max_cart_a=acc, elapsed_s=time.time() - t0))
        save(run / 'latest.zip')
        tag = ''
        if score > best:
            best = score; save(run / 'best.zip'); tag = '  BEST'
        streak = streak + 1 if ok == a.test_episodes else 0
        print(f'round {rnd:2d}  policy drives {100 * (1 - beta):3.0f}%  data {len(DO):>9,}  fit error {mse:.1e}  '
              f'test: {ok}/{a.test_episodes} pass, return {ret:6.1f}, cart acc max {acc:3.0f} m/s^2  '
              f'({(time.time() - t0) / 60:.1f} min){tag}', flush=True)
        json.dump(dict(phase='imitating', task=TASK, rounds=hist, best_passed=best[0], best_eval_return=best[1]),
                  open(run / 'status.json', 'w'), indent=1)
        if streak >= 3:
            print('All test episodes passed three rounds in a row: stopping early.'); break

    # ---- final check of best.zip with the standard evaluation (the one train.py uses), plus a video
    from common import load_policy
    pol = load_policy(run / 'best.zip', 'sac')
    ev = evaluate(pol, TASK, env_cfg, 20, video_path=None if a.no_video else run / 'videos' / 'imitation_best.mp4',
                  label=f'{a.name}  imitation of the planned swing-up', trace_path=None)
    solved = is_solved(TASK, ev)
    json.dump(dict(phase='imitated', task=TASK, rounds=hist, best_passed=best[0], best_eval_return=best[1],
                   final=dict(episodes=20, ep_return=ev['ep_return'], upright_frac=ev['upright_frac'],
                              best_hold_s=ev['best_hold_s'], ends=ev['ends'], passes_standard_test=bool(solved))),
              open(run / 'status.json', 'w'), indent=1)
    print(f"\nFinal check of best.zip, 20 episodes: return {ev['ep_return']:.1f} (the planned controller scores 946), "
          f"upright {100 * ev['upright_frac']:.0f}%, hold {ev['best_hold_s']:.1f} s, ends {''.join(e[0] for e in ev['ends'])}"
          f"  ->  {'PASSES' if solved else 'does NOT pass'} the triple swing-up test.")
    print(f'Watch it:  python watch.py --run {a.name} --policy best     Video: runs\\{a.name}\\videos\\imitation_best.mp4')


if __name__ == '__main__':
    main()
