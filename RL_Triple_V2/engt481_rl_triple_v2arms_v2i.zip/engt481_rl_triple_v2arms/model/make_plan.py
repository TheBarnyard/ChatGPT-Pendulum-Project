"""
Plan a swing-up for the triple model (model/params.json 'triple') and write model/triple_swingup_plan.json.

    pip install casadi
    python model/make_plan.py                 # 4.0 s, track 0.40 m, speed 1.2 m/s, accel 15 m/s^2
    python model/make_plan.py --T 3.0         # shorter and harder (found: uses the full 15 m/s^2)

Only needed again when the model changes (for example after  python model/build_triple_v2.py --arm3-hub bare);
the folder ships with the plan for the default model. It is the team's own planning problem (PUC Math/Triple,
04_swing_up.md): cart acceleration knots every 0.05 s, every 10 ms RK4 step a constraint, minimise the
integral of acceleration^2, start hanging at rest, end upright at rest, limits on track, speed, acceleration.
Solved with CasADi + IPOPT by continuation from loose limits (model/nlink_cart.py, plan_team_homotopy).
"""
import argparse, json, sys, time
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import nlink_cart as nl  # noqa: E402


def rig_from_params(kind='triple'):
    P = json.load(open(HERE / 'params.json'))[kind]
    links = [nl.Link(a['mass'], a['com_along'], a['length'], a['I_swing'], b)
             for a, b in zip(P['arms'], P['joint_damping'])]
    return nl.Rig(links, M=P['cart_mass'], b_cart=P['cart_damping']), P


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--T', type=float, default=4.0); p.add_argument('--track', type=float, default=0.40)
    p.add_argument('--speed', type=float, default=1.2); p.add_argument('--accel', type=float, default=15.0)
    p.add_argument('--top-speed', type=float, default=3.0, help='motor torque-speed limit (3.0 = barely active)')
    a = p.parse_args()
    rig, P = rig_from_params(); t0 = time.time()
    lg = lambda s: print(f'{s}  ({time.time() - t0:.0f} s)', flush=True)
    loose = (0.6, 2.0, 30.0, 3.0)
    first = nl.plan_team(rig, a.T, *loose, max_iter=3000)
    lg(f'T {a.T} s, loose limits: {first["status"]}, effort {first["effort"]:.1f}')
    if not first['ok']:
        raise SystemExit('No plan found even with loose limits; try a longer --T.')
    pl = nl.plan_team_homotopy(rig, a.T, a.track, a.speed, a.accel, a.top_speed, start_limits=loose,
                               min_step=1 / 32, guess=(first['Z'], first['knots']), log=lg)
    lim = pl.get('limits_reached', pl['limits'])
    out = dict(version=1, kind='triple', T=a.T, dt=0.01, z=np.round(pl['Z'].T, 8).tolist(),
               a=np.round(pl['a'], 8).tolist(), state='[th1, w1, th2, w2, th3, w3, x, v], angles from upright, absolute',
               limits=dict(track_m=lim['X'], speed_m_s=lim['V'], accel_m_s2=lim['A'], motor_top_speed_m_s=lim['Vtop']),
               peak=dict(track_m=pl['peak']['x'], speed_m_s=pl['peak']['v'], accel_m_s2=pl['peak']['a']),
               effort=pl['effort'], fraction_to_limits=pl.get('lam', 1.0),
               model_arms=P['arms'], model_joint_damping=P['joint_damping'],
               made=time.strftime('%Y-%m-%d %H:%M'))
    json.dump(out, open(HERE / 'triple_swingup_plan.json', 'w'))
    print(f'Wrote model/triple_swingup_plan.json: reached {out["fraction_to_limits"]:.2f} of the way to the limits, '
          f'peak track {out["peak"]["track_m"]:.3f} m, speed {out["peak"]["speed_m_s"]:.2f} m/s, '
          f'accel {out["peak"]["accel_m_s2"]:.1f} m/s^2')


if __name__ == '__main__':
    main()
