"""
Gymnasium environment for the ENGT481 cart TRIPLE (and double) pendulum, V2 arms, native MuJoCo.

Tasks
  triple_balance   start near upright, keep all three arms up   (V2 arms, arm 3 = 300 mm)
  triple_swingup   start hanging, swing all three up and hold   (the very hard one)
  double_balance / double_swingup are kept from the double folder (old CAD double model).

Training basis = the "BETTER TRAINING NUMBERS AND RESULT" version: same action, observation,
reward, start poses and limits. Tooling from v4.1 (diagnostic traces, per-factor logging,
behaviour flags, model-folder option) is added on top and does not change what is learned.

Action   : 1 value in [-1, 1] -> cart VELOCITY command = action * max_speed
           (same as the rig: the Pi sends a stepper pulse rate, 'xDiv')
           Optional --action-mode accel (from v4.1) integrates it as an acceleration instead.
Obs      : x/rail, xdot/max_speed, sin/cos of each ABSOLUTE arm angle,
           each absolute angular rate / 10, previous action  (+ commanded speed in accel mode)
Control  : 100 Hz policy, 1 kHz physics (10 substeps), like the real loop (Ts = 0.01)
"""
from pathlib import Path
from collections import deque
import numpy as np
import mujoco
import gymnasium as gym
from gymnasium import spaces

ROOT = Path(__file__).resolve().parent
MODEL_DIR = ROOT / 'model'            # corrected new arms (arm 1 200 mm, arm 2 250 mm)
N_ARMS = {'single': 1, 'double': 2, 'triple': 3}
ENV_VERSION = 'better-v2+v4.1tools+triple-v2d'   # solve history is kept per model + env version

TASKS = {
    'double_balance': dict(kind='double', start='upright', seconds=10, fail_angle=0.8),
    'double_swingup': dict(kind='double', start='hanging', seconds=10, fail_angle=None),
    # triple (V2 arms + 300 mm arm 3): swing-up gets 12 s; pass = swing up within 6 s, then hold >= 6 s
    'triple_balance': dict(kind='triple', start='upright', seconds=10, fail_angle=0.8),
    # v2b (2026-11-13): the plain reward gives ~0 for anything short of all three arms up, so the policy
    # learned to sit still. The triple swing-up gets a height reward and 30 % random-state starts instead.
    'triple_swingup': dict(kind='triple', start='hanging', seconds=12, fail_angle=None,
                           swing_s=6.0, pass_up_frac=0.45,
                           cfg=dict(reward='energy', explore_start_prob=0.3)),
}
DEFAULTS = dict(rail_limit=0.50, max_speed=1.4, ctrl_dt=0.01, randomize=False, model='model',
                rail_penalty=10.0, upright_start_prob=0.0,
                reward='plain',          # 'plain' (the better version), 'height' (v2b) or 'energy' (v2d, triple swing-up)
                explore_start_prob=0.0,  # training only: share of episodes that start in a random state
                spin_penalty=0.0,        # reward -= spin_penalty * sum(max(0, |w| - spin_limit)) (anti fan-blading)
                spin_limit=25.0,         # rad/s
                action_mode='velocity',  # 'velocity' (the better version), 'accel' (v4.1 option)
                max_accel=20.0,          # m/s^2, only used in accel mode
                loop_window_s=3.0, jolt_accel=4.0)   # diagnostics only (fan-blading / chatter counters)
UPRIGHT_DEG = 12.0       # "holding" = every arm within this of vertical and slow


def wrap(a):
    return (a + np.pi) % (2 * np.pi) - np.pi


class CartPendulumEnv(gym.Env):
    metadata = {'render_modes': ['rgb_array'], 'render_fps': 50}

    def __init__(self, task='double_swingup', render_mode=None, width=854, height=480, train_mode=False, **cfg):
        if task not in TASKS:
            raise ValueError(f'task must be one of {list(TASKS)}')
        self.task = task
        self.T = dict(TASKS[task])
        self.cfg = {**DEFAULTS, **self.T.get('cfg', {}), **{k: v for k, v in cfg.items() if v is not None}}
        self.train_mode = train_mode
        self.kind = self.T['kind']
        self.n_arms = N_ARMS[self.kind]
        self.model = mujoco.MjModel.from_xml_path(str(ROOT / self.cfg['model'] / f'{self.kind}_pendulum.xml'))
        try:                                   # arm lengths, for the height reward
            import json
            P = json.load(open(ROOT / self.cfg['model'] / 'params.json'))
            self.arm_L = np.array([a['length'] for a in P[self.kind]['arms']])
        except Exception:
            self.arm_L = np.array([0.2, 0.25, 0.3][:N_ARMS[self.kind]])
        self.h_max = float(np.cumsum(self.arm_L).sum())
        # energy reference for the 'energy' reward: arm potential energy hanging and upright (cart frame)
        self._arm_bodies = [mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_BODY, f'arm{i+1}') for i in range(N_ARMS[self.kind])]
        self._Mv = np.zeros(self.model.nv)
        d = mujoco.MjData(self.model)
        d.qpos[:] = 0; d.qpos[1] = np.pi; mujoco.mj_forward(self.model, d); self._pe_hang = self._pe(d)
        d.qpos[:] = 0; mujoco.mj_forward(self.model, d); self._pe_up = self._pe(d)
        self.data = mujoco.MjData(self.model)
        self.n_sub = int(round(self.cfg['ctrl_dt'] / self.model.opt.timestep))
        self.max_steps = int(self.T['seconds'] / self.cfg['ctrl_dt'])
        # allow a higher speed limit than the MJCF default if asked
        ms = self.cfg['max_speed']
        self.model.actuator_ctrlrange[0] = [-ms, ms]
        # nominal values for domain randomisation
        self._mass0 = self.model.body_mass.copy()
        self._inertia0 = self.model.body_inertia.copy()
        self._kv0 = self.model.actuator_gainprm[0, 0]

        self.accel_mode = self.cfg['action_mode'] == 'accel'
        self.v_cmd = 0.0
        n_obs = 3 + 3 * self.n_arms + (1 if self.accel_mode else 0)
        self.observation_space = spaces.Box(-np.inf, np.inf, (n_obs,), np.float32)
        self.action_space = spaces.Box(-1.0, 1.0, (1,), np.float32)
        self.render_mode = render_mode
        self._w, self._h = width, height
        self._renderer = None
        self._delay = 0
        self._pending = 0.0
        self.prev_action = 0.0
        self.last = {}

    # ------------------------------------------------------------------ helpers
    def _pe(self, d):
        return float(sum(self.model.body_mass[b] * 9.81 * d.xipos[b, 2] for b in self._arm_bodies))

    def arm_energy(self):
        """Arm energy above hanging, in the cart frame (cart motion left out), / the energy needed to stand up."""
        v = self.data.qvel.copy(); v[0] = 0.0                  # arm joint rates only (cart frame)
        mujoco.mj_mulM(self.model, self.data, self._Mv, v)
        ke = 0.5 * float(v @ self._Mv)
        return (self._pe(self.data) - self._pe_hang + ke) / (self._pe_up - self._pe_hang)

    def angles(self):
        q, v = self.data.qpos, self.data.qvel
        return np.cumsum(q[1:1 + self.n_arms]), np.cumsum(v[1:1 + self.n_arms])   # absolute angles

    def _obs(self):
        th, w = self.angles()
        if self.cfg['randomize']:
            th = th + self.np_random.normal(0, 0.002, th.shape)      # encoder-level noise
        x, xd = self.data.qpos[0], self.data.qvel[0]
        o = [x / self.cfg['rail_limit'], xd / self.cfg['max_speed']]
        o += list(np.sin(th)) + list(np.cos(th)) + list(w / 10.0) + [self.prev_action]
        if self.accel_mode:
            o.append(self.v_cmd / self.cfg['max_speed'])
        return np.asarray(o, dtype=np.float32)

    def is_upright(self):
        th, w = self.angles()
        return bool(np.all(np.abs(wrap(th)) < np.radians(UPRIGHT_DEG)) and np.all(np.abs(w) < 2.0))

    # ------------------------------------------------------------------ gym API
    def reset(self, seed=None, options=None):
        super().reset(seed=seed)
        m, d, rng = self.model, self.data, self.np_random
        mujoco.mj_resetData(m, d)
        if self.cfg['randomize']:
            s = rng.uniform(0.9, 1.1, m.nbody); s[0] = 1.0
            m.body_mass[:] = self._mass0 * s
            m.body_inertia[:] = self._inertia0 * s[:, None]
            m.actuator_gainprm[0, 0] = self._kv0 * rng.uniform(0.7, 1.2)
            m.actuator_biasprm[0, 2] = -m.actuator_gainprm[0, 0]
            self._delay = int(rng.integers(0, 2))                     # 0-10 ms extra latency
        start = self.T['start']
        if options and 'start' in options:
            start = options['start']
        elif self.train_mode and start == 'hanging':
            u = rng.random()
            if u < self.cfg['upright_start_prob']:
                start = 'upright'
            elif u < self.cfg['upright_start_prob'] + self.cfg['explore_start_prob']:
                start = 'random'
        if start == 'random':                  # anywhere on the circle, moderate speeds (training only)
            d.qpos[1:1 + self.n_arms] = rng.uniform(-np.pi, np.pi, self.n_arms)
        elif start == 'upright':
            d.qpos[1:1 + self.n_arms] = rng.uniform(-0.08, 0.08, self.n_arms)
        else:
            d.qpos[1:1 + self.n_arms] = rng.uniform(-0.1, 0.1, self.n_arms)
            d.qpos[1] += np.pi
        d.qpos[0] = rng.uniform(-0.05, 0.05)
        d.qvel[:] = rng.uniform(-0.05, 0.05, m.nv)
        if start == 'random':
            d.qpos[0] = rng.uniform(-0.2, 0.2)
            d.qvel[1:] = rng.uniform(-2.0, 2.0, m.nv - 1)
        mujoco.mj_forward(m, d)
        self.steps, self.ep_return, self.prev_action, self._pending = 0, 0.0, 0.0, 0.0
        self.hold, self.best_hold, self.up_steps = 0, 0, 0
        # diagnostics (v4.1): observed only, never part of the reward
        self.v_cmd, self.prev_v_cmd = 0.0, 0.0
        self.max_cart_v, self.max_arm_w, self.max_near_w = 0.0, 0.0, 0.0
        self.jolt_sign, self.jolt_times = 0, deque()
        self.th_hist = deque([self.angles()[0].copy()],
                             maxlen=int(round(self.cfg['loop_window_s'] / self.cfg['ctrl_dt'])) + 1)
        self.max_loops, self.max_jolts = 0.0, 0
        self.last = {}
        return self._obs(), {}

    def step(self, action):
        a = float(np.clip(np.asarray(action).reshape(-1)[0], -1, 1))
        cmd = a
        if self._delay:
            cmd, self._pending = self._pending, a
        ms = self.cfg['max_speed']
        if self.accel_mode:
            dv = self.cfg['max_accel'] * self.model.opt.timestep
            for _ in range(self.n_sub):
                self.v_cmd = float(np.clip(self.v_cmd + cmd * dv, -ms, ms))
                self.data.ctrl[0] = self.v_cmd
                mujoco.mj_step(self.model, self.data)
        else:
            self.v_cmd = cmd * ms
            self.data.ctrl[0] = self.v_cmd
            for _ in range(self.n_sub):
                mujoco.mj_step(self.model, self.data)
        self.steps += 1

        th, w = self.angles()
        x = self.data.qpos[0]
        # ---- reward: unchanged from the better version ----
        up_i = (1 + np.cos(th)) / 2                                  # 1 = upright, 0 = hanging
        if self.cfg['reward'] == 'height':
            # height of each link end above the cart pivot, 0 = all hanging, 1 = all upright; outer ends
            # count more (their height includes the links below). Partial credit for every bit of lift.
            z = np.cumsum(self.arm_L * np.cos(th))
            h = (z.sum() + self.h_max) / (2 * self.h_max)
            upright_term = 0.5 * h ** 2 + 0.5 * up_i.prod()
        elif self.cfg['reward'] == 'energy':
            # v2d: h**2 (v2b) is flat near hanging, so the policy still sat still. Linear height, plus an
            # energy term that peaks at exactly the upright energy (pumping pays at once, spinning does not),
            # plus the all-arms-upright product.
            z = np.cumsum(self.arm_L * np.cos(th))
            h = (z.sum() + self.h_max) / (2 * self.h_max)
            e_term = max(0.0, 1.0 - abs(self.arm_energy() - 1.0))
            upright_term = 0.3 * h + 0.2 * e_term + 0.5 * up_i.prod()
        else:
            upright_term = 0.2 * up_i.mean() + 0.8 * up_i.prod()
        centered = 0.5 + 0.5 * np.exp(-(x / 0.3) ** 2)
        calm = np.exp(-0.01 * np.sum(w ** 2))
        effort = 0.01 * a ** 2 + 0.02 * (a - self.prev_action) ** 2
        reward = upright_term * centered * (0.8 + 0.2 * calm) - effort
        if self.cfg['spin_penalty']:
            reward -= self.cfg['spin_penalty'] * float(np.sum(np.maximum(0.0, np.abs(w) - self.cfg['spin_limit'])))

        # ---- diagnostics (v4.1 tooling, does not affect the reward) ----
        cmd_acc = (self.v_cmd - self.prev_v_cmd) / self.cfg['ctrl_dt']
        self.prev_v_cmd = self.v_cmd
        self.max_cart_v = max(self.max_cart_v, abs(self.data.qvel[0]))
        self.th_hist.append(th.copy())
        turns = np.abs(th - self.th_hist[0]) / (2 * np.pi)
        self.max_loops = max(self.max_loops, float(turns.max()))
        j = self.cfg['jolt_accel']
        if (cmd_acc > j and self.jolt_sign < 0) or (cmd_acc < -j and self.jolt_sign > 0):
            self.jolt_times.append(self.steps)
        if abs(cmd_acc) > j:
            self.jolt_sign = 1 if cmd_acc > 0 else -1
        win = int(round(1.0 / self.cfg['ctrl_dt']))
        while self.jolt_times and self.steps - self.jolt_times[0] >= win:
            self.jolt_times.popleft()
        rate = len(self.jolt_times)
        self.max_jolts = max(self.max_jolts, rate)
        self.max_arm_w = max(self.max_arm_w, float(np.abs(w).max()))
        near = np.abs(wrap(th)) < np.radians(30.0)
        if np.any(near): self.max_near_w = max(self.max_near_w, float(np.abs(w[near]).max()))
        self.prev_action = a

        terminated = False
        reason = ''
        crash = 0.0
        if abs(x) >= self.cfg['rail_limit']:
            terminated, reason, crash = True, 'rail', self.cfg['rail_penalty']
            reward -= crash
        elif self.T['fail_angle'] and np.any(np.abs(wrap(th)) > self.T['fail_angle']):
            terminated, reason = True, 'fell'
        elif not np.all(np.isfinite(self.data.qpos)):
            terminated, reason = True, 'nan'
        truncated = self.steps >= self.max_steps
        self.last = dict(up=float(upright_term), centered=float(centered), calm=float(0.8 + 0.2 * calm),
                         effort=float(effort), jolt_rate=rate, turns=float(turns.max()), cmd_acc=cmd_acc,
                         r=float(reward), crash=crash)

        if self.is_upright():
            self.hold += 1; self.up_steps += 1
            self.best_hold = max(self.best_hold, self.hold)
        else:
            self.hold = 0
        self.ep_return += reward
        info = {}
        if terminated or truncated:
            info = dict(ep_return=self.ep_return, ep_steps=self.steps, end=reason or 'time',
                        upright_frac=self.up_steps / self.steps,
                        best_hold_s=self.best_hold * self.cfg['ctrl_dt'],
                        max_cart_v=self.max_cart_v, max_arm_w=self.max_arm_w, max_near_w=self.max_near_w,
                        max_loops=self.max_loops, max_jolts=self.max_jolts)
        return self._obs(), float(reward), terminated, truncated, info

    # ------------------------------------------------------------------ rendering
    def render(self, overlay=None):
        if self._renderer is None:
            self._renderer = mujoco.Renderer(self.model, self._h, self._w)
            self._cam = mujoco.MjvCamera()
            self._cam.azimuth, self._cam.elevation = 90.0, -12.0
            self._cam.distance = {1: 1.2, 2: 1.6, 3: 2.3}[self.n_arms]
        x = self.data.qpos[0]
        self._cam.lookat[:] = [0.6 * x, -0.08, {1: 0.10, 2: 0.12, 3: 0.20}[self.n_arms]]
        self._renderer.update_scene(self.data, camera=self._cam)
        img = self._renderer.render()
        if overlay:
            img = draw_text(img, overlay)
        return img

    def close(self):
        if self._renderer is not None:
            self._renderer.close(); self._renderer = None


_FONT = None
def draw_text(img, lines):
    """Burn a small HUD into a frame (PIL; falls back silently)."""
    global _FONT
    try:
        from PIL import Image, ImageDraw, ImageFont
        if _FONT is None:
            try: _FONT = ImageFont.truetype('DejaVuSansMono.ttf', 18)
            except Exception:
                try: _FONT = ImageFont.truetype('consola.ttf', 18)
                except Exception: _FONT = ImageFont.load_default()
        im = Image.fromarray(img); dr = ImageDraw.Draw(im)
        y = 10
        for ln in lines:
            dr.text((13, y + 1), ln, fill=(0, 0, 0), font=_FONT)
            dr.text((12, y), ln, fill=(255, 255, 255), font=_FONT)
            y += 24
        return np.asarray(im)
    except Exception:
        return img


def make_env(task, rank=0, seed=0, **cfg):
    def _init():
        env = CartPendulumEnv(task, **cfg)
        env.reset(seed=seed + rank)
        return env
    return _init
