# Corrected pendulum arms: MuJoCo model folder

This folder packages the corrected arm assemblies in the model-folder format of the supplied training project. The cart, rail, actuator configuration, and base/cart mesh files come from the supplied `engt481_rl.zip`. No past runs, training results, or checkpoints are included.

## Corrected assembly

- The plain proximal hole of the short arm mounts to the cart shaft.
- Arm 1 is 200 mm between pivots. Its distal electronics measure the relative angle between arms 1 and 2.
- Arm 2 is 250 mm long. Its distal electronics are reserved for the future arm 2/arm 3 joint. Its far end has no shaft.
- The shaft, collar, magnet, and inner bearing race at the middle joint rotate with arm 2. Their mass is assigned to arm 2 in the double model.
- Arm planes are separated by 25 mm. This is a retained model assumption.

## Contents

| File | Purpose |
|---|---|
| `double_pendulum.xml` | Complete MuJoCo double pendulum, cart, rail, actuator, and sensors |
| `single_pendulum.xml` | Matching single pendulum configuration |
| `double_pendulum.urdf`, `single_pendulum.urdf` | Visual/inertial/joint exports; use XML for the training actuator and MuJoCo settings |
| `meshes/` | Individual STL parts, coordinates in metres |
| `arm1.glb`, `arm2.glb` | Double-model link assemblies in their own upright local frames |
| `arm1_single.glb` | Single assembly with the distal shaft hardware attached |
| `base.glb`, `cart.glb` | Cart and rail visuals from the supplied training folder |
| `params.json` | Training-compatible masses, COM distances, lengths, and swing-axis COM inertias |
| `geometry.json` | Mesh/material inventory and corrected model-frame inertial properties |
| `mass_properties.json` | Original corrected assembly component accounting, in its original source frame and units |
| `model_settings.json` | Cart settings and source-to-model coordinate transform |
| `model_review.png` | Render of the double model hanging from the cart |
| `validation.json` | Results of compilation and short environment checks |
| `preview.py` | Interactive MuJoCo viewer |

## Install and view

Keep a backup of the existing training project's `model` folder. Extract this ZIP beside it, then use the extracted `model` folder in its place. Keep the XML files and `meshes` folder together. This package provides single and double models only; it does not update a triple-arm model or existing controller gains.

From the training project directory, using the same Python environment:

```powershell
python .\model\preview.py
```

If MuJoCo is not installed:

```powershell
python -m pip install mujoco
```

The preview opens in the hanging position. Drag in the viewer to rotate the camera and use the scroll wheel to zoom. For the single model:

```powershell
python .\model\preview.py --kind single
```

The preview is static by default for inspecting the assembly. `--simulate` enables passive physics; it does not train or run a swing-up controller.

## Coordinates and angle definitions

World X is rail travel, Z is up, and hinge axes are +Y. Zero arm angles are upright. Positive arm 1 angle tips toward +X. Joint 2 is a relative angle, so arm 2's absolute angle is `q1 + q2`. In the hanging configuration, `q1 = pi` and `q2 = 0`.

The original corrected CAD-style source frame has +X along the arm and +Z along the shaft. Its coordinates are rotated into the training frame as follows:

```text
model_x = -source_y
model_y = -source_z
model_z =  source_x
```

The XML and URDF inertial values are in SI units: metres, kilograms, and kg m^2. `mass_properties.json` retains the original source-frame component quantities, including millimetres, grams, and g mm^2 where labelled; do not insert those raw numbers into XML. Full inertia tensors and COM vectors have already been transformed into the model frame.

## Mass properties retained from the corrected assembly

| Configuration / body | Mass (kg) | COM distance along arm from proximal pivot (m) | Swing-axis inertia about COM (kg m^2) |
|---|---:|---:|---:|
| Single arm 1, including distal shaft hardware | 0.148086 | 0.165409 | 0.000430668 |
| Double arm 1 | 0.098136 | 0.147803 | 0.000339765 |
| Double arm 2, including incoming middle-joint hardware | 0.161803 | 0.128897 | 0.001818396 |

These are model estimates, not measured mass properties. Retained assumptions include a 14 g battery, a 34.5 g printed arm 1 body, arm 2 printed mass scaled by mesh volume, and a 60/40 bearing-mass allocation. PLA infill alone does not uniquely determine printed mass: shells, solid layers, local reinforcement, and actual hardware affect it. Measure assembled masses and COM positions before treating these numbers as hardware identification results.

The double arm 2 COM is closer to its proximal pivot than the bare arm 2 assembly's COM because the incoming shaft hardware is counted near that pivot. This does not move its electronics to the proximal end. The single and double arm 1 masses differ because the joint shaft belongs to the moving child in the double configuration.

## Preserved cart and rail settings

- Base length: 1500 mm; rail rods: 1200 mm.
- Cart mass: 0.969 kg; cart damping: 0.5 N s/m.
- Mechanical cart joint range: -0.503 to +0.503 m.
- Supplied training default termination range: -0.500 to +0.500 m, set by the trainer rather than this model.
- Velocity actuator: gain 400, command range -1.4 to +1.4 m/s, force limit 95 N.
- Physics step: 0.001 s; RK4 integration.
- Contacts remain disabled as in the supplied model. The visual meshes do not enforce hardware collisions.

## Validation and limits

Both XML models compile in MuJoCo and remain finite during a two-second physics check. Both URDF files compile. The supplied training environments completed 100 steps each for single and double swing-up using this folder. Cart and base STL bytes were checked unchanged. Hanging and bent-joint kinematics were checked, including the 200 mm arm 1 pivot spacing and 25 mm axial separation.

These checks establish that the files load and the model interfaces work. They do not establish physical parameter accuracy, controller stability, or successful swing-up. No retraining was performed for this model-only package. Recompute model-dependent controller gains and retrain policies before comparing performance on these new dynamics.

MuJoCo model-format reference: https://mujoco.readthedocs.io/en/latest/XMLreference.html
