"""Open the corrected model at its hanging configuration."""
from pathlib import Path
import argparse
import time
import mujoco
import mujoco.viewer

parser = argparse.ArgumentParser()
parser.add_argument('--kind', choices=['single', 'double'], default='double')
parser.add_argument('--simulate', action='store_true')
args = parser.parse_args()
model = mujoco.MjModel.from_xml_path(str(Path(__file__).parent / f'{args.kind}_pendulum.xml'))
data = mujoco.MjData(model)
key = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_KEY, 'hanging')
mujoco.mj_resetDataKeyframe(model, data, key)
mujoco.mj_forward(model, data)
with mujoco.viewer.launch_passive(model, data) as viewer:
    viewer.cam.lookat[:] = [0, -.08, -.1]
    viewer.cam.distance = 1.8
    viewer.cam.azimuth = 90
    viewer.cam.elevation = -10
    while viewer.is_running():
        start = time.perf_counter()
        if args.simulate:
            for _ in range(10):
                mujoco.mj_step(model, data)
        viewer.sync()
        time.sleep(max(0, .01 - (time.perf_counter() - start)))
