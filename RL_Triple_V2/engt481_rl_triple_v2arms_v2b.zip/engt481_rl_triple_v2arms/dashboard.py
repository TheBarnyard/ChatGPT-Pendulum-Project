"""
Browser dashboard: live 3D view of the current policy, progress/ETA, learning curves, eval videos.

  python dashboard.py            then open http://localhost:8000
  python dashboard.py --port 8001 --no-live     (charts + videos only, no live render)

The live view is a real-time MuJoCo render of the NEWEST checkpoint of the selected run
(reloaded automatically as training saves), streamed to the page as MJPEG.
"""
import argparse, io, json, os, sys, threading, time, webbrowser
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs, unquote
import numpy as np

os.environ.setdefault('MUJOCO_GL', 'egl' if sys.platform.startswith('linux') else 'glfw')
from common import RUNS, resolve_run, run_config, load_policy, policy_step

STATE = dict(frame=None, run=None, follow=True, msg='starting', lock=threading.Lock(), frame_id=0)


# ------------------------------------------------------------------ live render loop (main thread)
def live_loop(width=800, height=450, fps=30):
    from pendulum_env import CartPendulumEnv
    from PIL import Image
    env = policy = None; cur_run = None; mtime = 0; task = None; last_check = 0
    while True:
        t0 = time.time()
        try:
            want = None if STATE['follow'] else STATE['run']
            if want is None and (RUNS / 'LATEST').exists():      # follow: whatever is training now
                want = (RUNS / 'LATEST').read_text().strip()
            if want and want != cur_run:
                run_dir = resolve_run(want); cfg = run_config(run_dir)
                task = cfg['task']
                if env: env.close()
                ecfg = {k: v for k, v in cfg.get('env_cfg', {}).items() if k != 'upright_start_prob'}
                env = CartPendulumEnv(task, width=width, height=height, **ecfg)
                obs, _ = env.reset(); policy = None; mtime = 0; cur_run = want; ep = 1
                STATE['msg'] = 'waiting for first checkpoint'
            if env is None:
                STATE['msg'] = 'no runs yet'; time.sleep(0.5); continue
            if time.time() - last_check > 2:
                last_check = time.time()
                pp = run_dir / 'latest.zip'
                if pp.exists() and pp.stat().st_mtime > mtime:
                    try:
                        policy = load_policy(pp, cfg['algo']); mtime = pp.stat().st_mtime
                        ps = policy_step(run_dir, pp)
                        STATE['msg'] = f"policy saved at step {ps:,}" if ps is not None else 'policy loaded'
                    except Exception as e:
                        STATE['msg'] = f'reload failed: {e}'
            # advance the sim in real time: 100 control steps per second of wall clock
            sim_acc = STATE.get('sim_acc', 0.0) + 100.0 / fps
            n = int(sim_acc); STATE['sim_acc'] = sim_acc - n
            for _ in range(n):
                act = policy.predict(obs, deterministic=True)[0] if policy else np.zeros(1)
                obs, r, term, trunc, info = env.step(act)
                if term or trunc:
                    obs, _ = env.reset(); ep += 1; break
            th, _ = env.angles()
            hud = [f"LIVE  {cur_run}", f"{STATE['msg']}   episode {ep}",
                   f"t {env.steps*0.01:5.2f} s  x {env.data.qpos[0]*1000:+5.0f} mm  theta "
                   + ' '.join(f'{np.degrees((a+np.pi)%(2*np.pi)-np.pi):+6.1f}' for a in th),
                   f"return {env.ep_return:6.1f}   hold {env.hold*0.01:4.1f} s"]
            img = env.render(hud)
            buf = io.BytesIO(); Image.fromarray(img).save(buf, 'JPEG', quality=78)
            with STATE['lock']:
                STATE['frame'] = buf.getvalue(); STATE['frame_id'] += 1
        except Exception as e:
            STATE['msg'] = f'live view error: {e}'; time.sleep(1)
        dt = 1.0 / fps - (time.time() - t0)
        if dt > 0: time.sleep(dt)


# ------------------------------------------------------------------ HTTP
def list_runs():
    out = []
    if RUNS.exists():
        for d in sorted(RUNS.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True):
            s = d / 'status.json'
            if d.is_dir() and s.exists():
                try:
                    st = json.load(open(s))
                    alive = time.time() - st.get('updated', 0) < 30 and st.get('phase') not in ('done', 'stopped', 'solved')
                    out.append(dict(name=d.name, task=st.get('task'), phase=st.get('phase') if alive or st.get('phase') in ('done', 'stopped', 'solved') else 'stalled/killed',
                                    steps=st.get('steps'), total=st.get('total_steps'), best=st.get('best_eval_return')))
                except Exception:
                    pass
    return out


def latest_video(run_dir):
    """The newest eval whose video has finished rendering."""
    try: st = json.load(open(run_dir / 'status.json'))
    except Exception: return None, None
    evs = [e for e in st.get('evals', []) if e.get('video') and (run_dir / 'videos' / e['video']).exists()]
    if not evs: return None, st
    return max(evs, key=lambda e: e['steps']), st


def lanes():
    """Which run each lane (balance / swing-up) is on. run_all.py writes runs/lanes.json; without it
    (train.py started by hand) the newest balance run and the newest swing-up run are used."""
    out = []
    try:
        doc = json.load(open(RUNS / 'lanes.json'))
        if time.time() - doc.get('updated', 0) < 120 or all(l.get('state') == 'done' for l in doc['lanes']):
            out = [dict(lane=l['lane'], device=l.get('device'), run=l.get('run'), task=l.get('task'),
                        state=l.get('state'), n=l.get('n'), of=l.get('of')) for l in doc['lanes']]
            if len(out) == 1 and out[0]['lane'] == 'serial': out = []    # serial mode: fall back to newest of each kind
    except Exception:
        pass
    if not out:
        for lane, suffix in (('balance', 'balance'), ('swing', 'swingup')):
            cands = [r for r in list_runs() if (r.get('task') or '').endswith(suffix)]
            if cands:
                r = cands[0]
                out.append(dict(lane=lane, device=None, run=r['name'], task=r['task'], state=r['phase'], n=None, of=None))
            else:
                out.append(dict(lane=lane, device=None, run=None, task=None, state='no runs yet', n=None, of=None))
    for l in out:
        l['video'] = l['eval'] = None
        if l['run'] and (RUNS / l['run']).is_dir():
            ev, st = latest_video(RUNS / l['run'])
            if st: l['phase'] = st.get('phase'); l['steps'] = st.get('steps'); l['n_evals'] = len(st.get('evals', [])); l['best'] = st.get('best_eval_return')
            if ev:
                l['video'] = ev['video']
                l['eval'] = {k: ev.get(k) for k in ('steps', 'ep_return', 'upright_frac', 'best_hold_s', 'ends',
                                                    'max_arm_w', 'max_loops', 'max_jolts', 'max_cart_v', 'passed')}
                l['eval']['flags'] = (ev.get('diag') or {}).get('flags', [])
    return out


class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def send(self, code, body, ctype='application/json', extra=None):
        if isinstance(body, (dict, list)): body = json.dumps(body).encode()
        if isinstance(body, str): body = body.encode()
        self.send_response(code); self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(body))); self.send_header('Cache-Control', 'no-store')
        for k, v in (extra or {}).items(): self.send_header(k, v)
        self.end_headers(); self.wfile.write(body)

    def do_GET(self):
        u = urlparse(self.path); q = parse_qs(u.query)
        try:
            if u.path == '/':
                return self.send(200, PAGE, 'text/html; charset=utf-8')
            if u.path == '/api/runs':
                return self.send(200, dict(runs=list_runs(), follow=STATE['follow'],
                                           training_run=(RUNS / 'LATEST').read_text().strip() if (RUNS / 'LATEST').exists() else None,
                                           live_run=STATE['run'] or
                                           ((RUNS / 'LATEST').read_text().strip() if (RUNS / 'LATEST').exists() else None)))
            if u.path == '/report.zip':
                import report
                out, n = report.make(q.get('prefix', [None])[0])
                data = out.read_bytes()
                return self.send(200, data, 'application/zip',
                                 {'Content-Disposition': f'attachment; filename="{out.name}"'})
            if u.path == '/api/lanes':
                return self.send(200, dict(lanes=lanes()))
            if u.path == '/api/status':
                d = resolve_run(q.get('run', ['latest'])[0])
                st = json.load(open(d / 'status.json'))
                st['videos'] = sorted(p.name for p in (d / 'videos').glob('step_*.mp4') if '.tmp' not in p.name)
                st['stale'] = time.time() - st.get('updated', 0) > 30 and st.get('phase') not in ('done', 'stopped', 'solved')
                return self.send(200, st)
            if u.path == '/api/live':
                if 'follow' in q:
                    STATE['follow'] = q['follow'][0] == '1'
                if 'run' in q:
                    STATE['run'] = q['run'][0]; STATE['follow'] = False
                return self.send(200, dict(ok=True, follow=STATE['follow']))
            if u.path.startswith('/video/'):
                _, _, run, name = u.path.split('/', 3)
                f = RUNS / unquote(run) / 'videos' / unquote(name)
                return self.send_file(f)
            if u.path == '/live.mjpg':
                self.send_response(200)
                self.send_header('Content-Type', 'multipart/x-mixed-replace; boundary=frame')
                self.send_header('Cache-Control', 'no-store'); self.end_headers()
                last = -1
                while True:
                    with STATE['lock']:
                        fid, fr = STATE['frame_id'], STATE['frame']
                    if fr is not None and fid != last:
                        last = fid
                        self.wfile.write(b'--frame\r\nContent-Type: image/jpeg\r\nContent-Length: '
                                         + str(len(fr)).encode() + b'\r\n\r\n' + fr + b'\r\n')
                    time.sleep(0.015)
            self.send(404, {'error': 'not found'})
        except (BrokenPipeError, ConnectionResetError):
            pass
        except SystemExit as e:
            self.send(404, {'error': str(e)})
        except Exception as e:
            try: self.send(500, {'error': str(e)})
            except Exception: pass

    def send_file(self, f):
        if not f.exists(): return self.send(404, {'error': 'no file'})
        size = f.stat().st_size; rng = self.headers.get('Range')
        start, end = 0, size - 1
        if rng and rng.startswith('bytes='):
            a, b = rng[6:].split('-'); start = int(a or 0); end = int(b) if b else size - 1
            self.send_response(206); self.send_header('Content-Range', f'bytes {start}-{end}/{size}')
        else:
            self.send_response(200)
        self.send_header('Content-Type', 'video/mp4'); self.send_header('Accept-Ranges', 'bytes')
        self.send_header('Content-Length', str(end - start + 1)); self.end_headers()
        with open(f, 'rb') as fh:
            fh.seek(start); self.wfile.write(fh.read(end - start + 1))


PAGE = r"""<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>ENGT481 RL Dashboard</title>
<style>
:root{--bg:#14181d;--panel:#1c2229;--line:#2d353f;--ink:#e6e9ed;--muted:#96a0ab;--acc:#ee8440;--blue:#5f9de0;--ok:#4cbb7f;--bad:#e0605a;
font-family:system-ui,-apple-system,"Segoe UI",sans-serif;color-scheme:dark}
body{margin:0;background:var(--bg);color:var(--ink);font-size:14px}
header{display:flex;flex-wrap:wrap;gap:12px;align-items:center;padding:12px 18px;border-bottom:1px solid var(--line);background:var(--panel)}
h1{font-size:18px;margin:0;font-weight:600}
select{background:var(--bg);color:var(--ink);border:1px solid var(--line);border-radius:6px;padding:6px 8px;font-size:13px;max-width:100%}
.pill{padding:3px 10px;border-radius:99px;font:600 12px ui-monospace,Consolas,monospace;background:#2a323c}
.pill.training{background:#1f4a33;color:#9fe3bd}.pill.evaluating{background:#4a3a1f;color:#f3cf94}
.pill.done,.pill.solved{background:#23384f;color:#a9cdf5}.pill.stale{background:#4f2323;color:#f5a9a9}
main{display:grid;grid-template-columns:minmax(0,1.35fr) minmax(0,1fr);gap:16px;padding:16px 18px}
@media(max-width:1000px){main{grid-template-columns:1fr}}
.card{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:14px}
.card h2{margin:0 0 10px;font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:var(--muted)}
#live{width:100%;aspect-ratio:16/9;background:#000;border-radius:6px;display:block}
.bar{height:14px;background:#0f1317;border-radius:7px;overflow:hidden;border:1px solid var(--line)}
.bar i{display:block;height:100%;background:linear-gradient(90deg,var(--acc),#f5a66f);width:0%}
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:10px;margin-top:12px}
.stat span{display:block;color:var(--muted);font-size:12px}.stat b{font:600 17px ui-monospace,Consolas,monospace;font-variant-numeric:tabular-nums}
canvas{width:100%;height:190px;display:block}
.legend{display:flex;gap:14px;color:var(--muted);font-size:12px;margin-top:4px;flex-wrap:wrap}.legend i{display:inline-block;width:12px;height:3px;margin-right:5px;vertical-align:3px}
.vids{display:flex;flex-direction:column;gap:12px}
.vids figure{margin:0}.vids video{width:100%;border-radius:6px;background:#000}
.vids figcaption{color:var(--muted);font:12px ui-monospace,Consolas,monospace;margin-top:4px}
.stack{display:flex;flex-direction:column;gap:16px}
.note{color:var(--muted);font-size:12px;margin:8px 0 0}
.lanes{display:grid;grid-template-columns:1fr 1fr;gap:16px;padding:16px 18px 0}
@media(max-width:1000px){.lanes{grid-template-columns:1fr}}
.lane h2{display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap}
.lane video{width:100%;aspect-ratio:16/9;background:#000;border-radius:6px;display:block}
.lane .empty{width:100%;aspect-ratio:16/9;background:#0f1317;border-radius:6px;display:flex;align-items:center;justify-content:center;color:var(--muted);text-align:center;padding:0 12px;box-sizing:border-box}
.lane .cap{font:12px ui-monospace,Consolas,monospace;color:var(--muted);margin-top:6px;line-height:1.6}
.lane .cap b{color:var(--ink)}.tag{font-weight:600;color:var(--ok)}
</style></head><body>
<header><h1>ENGT481 RL</h1><select id="run"></select><label style="display:flex;gap:6px;align-items:center;color:var(--muted);font-size:13px"><input type="checkbox" id="follow" checked>Follow training</label><span class="pill" id="phase">-</span>
<span class="note" id="upd" style="margin:0"></span>
<a href="/report.zip" style="margin-left:auto;color:var(--ink);background:#2a323c;border:1px solid var(--line);border-radius:6px;padding:6px 12px;text-decoration:none;font-size:13px" title="Everything needed to diagnose this session, in one zip. Upload it to Claude.">Download diagnostic report</a></header>
<section class="lanes">
 <div class="card lane" id="L_balance"><h2><span>Balance lane - latest eval</span><span class="pill" data-k="pill">-</span></h2><div data-k="box"><div class="empty">waiting for the first evaluation video</div></div><div class="cap" data-k="cap"></div></div>
 <div class="card lane" id="L_swing"><h2><span>Swing-up lane - latest eval</span><span class="pill" data-k="pill">-</span></h2><div data-k="box"><div class="empty">waiting for the first evaluation video</div></div><div class="cap" data-k="cap"></div></div>
</section>
<main>
 <div class="stack">
  <div class="card"><h2>Live policy (real time, newest checkpoint)</h2><img id="live" src="/live.mjpg" alt="live render">
   <p class="note">This is the newest saved policy running in its own MuJoCo sim, not the batch being trained. It reloads each time the trainer saves.</p></div>
  <div class="card"><h2>Progress</h2><div class="bar"><i id="pbar"></i></div>
   <div class="stats">
    <div class="stat"><span>Steps</span><b id="sSteps">-</b></div><div class="stat"><span>Complete</span><b id="sPct">-</b></div>
    <div class="stat"><span>Speed</span><b id="sSps">-</b></div><div class="stat"><span>Elapsed</span><b id="sEl">-</b></div>
    <div class="stat"><span>ETA likely</span><b id="sEtaL">-</b><span id="sEtaB" style="font-size:11px"></span></div><div class="stat"><span>ETA max (step budget)</span><b id="sEta">-</b></div><div class="stat"><span>Episodes</span><b id="sEp">-</b></div>
    <div class="stat"><span>Train return (last 50)</span><b id="sTr">-</b></div><div class="stat"><span>Best eval return</span><b id="sBest">-</b></div>
   </div></div>
 </div>
 <div class="stack">
  <div class="card"><h2>Evaluation (deterministic, from the task start pose)</h2><canvas id="c1" width="900" height="380"></canvas>
   <div class="legend"><span><i style="background:var(--acc)"></i>eval return</span><span><i style="background:#8b95a1"></i>train return</span></div>
   <canvas id="c2" width="900" height="380" style="margin-top:10px"></canvas>
   <div class="legend"><span><i style="background:var(--blue)"></i>% time upright</span><span><i style="background:var(--ok)"></i>longest hold (s, right axis)</span></div></div>
  <div class="card"><h2>Evaluation videos (newest first)</h2><div class="vids" id="vids"></div></div>
 </div>
</main>
<script>
const $=id=>document.getElementById(id); let run=null, shown='';
const fmt=s=>{if(s==null)return'-';s=Math.max(0,Math.round(s));const h=Math.floor(s/3600),m=Math.floor(s%3600/60),x=s%60;return`${h}:${String(m).padStart(2,'0')}:${String(x).padStart(2,'0')}`};
async function runs(){const r=await (await fetch('/api/runs')).json();const sel=$('run');
 sel.innerHTML=r.runs.map(x=>`<option value="${x.name}">${x.name} - ${x.phase}</option>`).join('');
 $('follow').checked=r.follow;
 let want=r.follow?(r.training_run||r.live_run):(run||r.live_run);       // follow: jump to the task being trained
 if(want&&r.runs.some(x=>x.name===want)){ if(want!==run){run=want;shown='';tick();} sel.value=run; }
 else if(!run&&sel.value){run=sel.value;}}
$('follow').onchange=e=>{fetch('/api/live?follow='+(e.target.checked?1:0)).then(runs);};
$('run').onchange=e=>{run=e.target.value;shown='';$('follow').checked=false;fetch('/api/live?run='+encodeURIComponent(run));tick();};
function chart(cv,xs,series,right){const c=cv.getContext('2d'),W=cv.width,H=cv.height,L=60,R=right?60:14,T=12,B=34;c.clearRect(0,0,W,H);
 if(!xs.length){c.fillStyle='#96a0ab';c.font='22px system-ui';c.fillText('first evaluation runs as training starts',L,H/2);return}
 const xmax=Math.max(...xs,1);const X=v=>L+(W-L-R)*v/xmax;
 c.strokeStyle='#2d353f';c.lineWidth=1;c.fillStyle='#96a0ab';c.font='18px ui-monospace,Consolas,monospace';
 for(let i=0;i<=4;i++){const y=T+(H-T-B)*i/4;c.beginPath();c.moveTo(L,y);c.lineTo(W-R,y);c.stroke();}
 for(let i=0;i<=4;i++){const v=xmax*i/4;c.fillText(v>=1e6?(v/1e6).toFixed(1)+'M':Math.round(v/1e3)+'k',X(v)-18,H-8);}
 series.forEach((s,si)=>{const vals=s.v.filter(v=>v!=null&&isFinite(v));if(!vals.length)return;let lo=s.lo??Math.min(0,...vals),hi=s.hi??Math.max(...vals,1e-6);if(hi<=lo)hi=lo+1;
  const Y=v=>T+(H-T-B)*(1-(v-lo)/(hi-lo));
  if(s.axis!=='hidden'){const xa=s.axis==='right'?W-R+6:4;c.fillStyle=s.c;for(let i=0;i<=4;i++){const v=hi-(hi-lo)*i/4;c.fillText((Math.abs(v)>=100?v.toFixed(0):v.toFixed(1)).padStart(5),xa,T+(H-T-B)*i/4+6);}}
  c.strokeStyle=s.c;c.lineWidth=3;c.beginPath();let first=true;s.v.forEach((v,i)=>{if(v==null||!isFinite(v))return;first?c.moveTo(X(xs[i]),Y(v)):c.lineTo(X(xs[i]),Y(v));first=false});c.stroke();
  const li=s.v.length-1;if(s.v[li]!=null){c.fillStyle=s.c;c.beginPath();c.arc(X(xs[li]),Y(s.v[li]),5,0,7);c.fill();}});}
async function tick(){if(!run)return;let s;try{s=await (await fetch('/api/status?run='+encodeURIComponent(run))).json()}catch(e){return}
 if(s.error)return; const pct=100*s.steps/s.total_steps; $('pbar').style.width=pct.toFixed(1)+'%';
 const ph=s.stale?'stale':s.phase;$('phase').textContent=s.stale?'no update >30 s (stopped?)':s.phase;$('phase').className='pill '+ph;
 $('sSteps').textContent=s.steps.toLocaleString()+' / '+s.total_steps.toLocaleString();$('sPct').textContent=pct.toFixed(1)+'%';
 $('sSps').textContent=Math.round(s.steps_per_s)+' st/s';$('sEl').textContent=fmt(s.elapsed_s);const fin=(s.phase==='done'||s.phase==='solved'||s.phase==='stopped');$('sEta').textContent=fin?s.phase:fmt(s.eta_s);$('sEtaL').textContent=fin?s.phase:(s.eta_likely_s==null?'-':fmt(s.eta_likely_s));$('sEtaB').textContent=fin?'':(s.eta_likely_basis||'');
 $('sEp').textContent=s.episodes??'-';$('sTr').textContent=s.train_return==null?'-':s.train_return.toFixed(1);
 $('sBest').textContent=s.best_eval_return==null?'-':s.best_eval_return.toFixed(1);
 $('upd').textContent=s.task+' · '+s.algo.toUpperCase()+' · updated '+new Date(s.updated*1000).toLocaleTimeString();
 const E=s.evals||[],xs=E.map(e=>e.steps);
 chart($('c1'),xs,[{v:E.map(e=>e.ep_return),c:'#ee8440'},{v:E.map(e=>e.train_return??null),c:'#8b95a1',axis:'hidden'}]);
 chart($('c2'),xs,[{v:E.map(e=>100*e.upright_frac),c:'#5f9de0',lo:0,hi:100},{v:E.map(e=>e.best_hold_s),c:'#4cbb7f',lo:0,axis:'right'}],true);
 const vids=[...s.videos].reverse(),key=run+vids.join();
 if(key!==shown){shown=key;$('vids').innerHTML=vids.slice(0,12).map(v=>{const ev=E.find(e=>e.video===v);
  return `<figure><video controls preload="metadata" src="/video/${encodeURIComponent(run)}/${v}"></video><figcaption>${v.replace('.mp4','')}${ev?` · return ${ev.ep_return.toFixed(1)} · upright ${(100*ev.upright_frac).toFixed(0)}% · hold ${ev.best_hold_s.toFixed(1)} s`:''}</figcaption></figure>`}).join('')||'<p class="note">Videos appear after each evaluation.</p>';}}
const laneKey={};
async function lanes(){let r;try{r=await (await fetch('/api/lanes')).json()}catch(e){return}
 for(const l of r.lanes){const card=$('L_'+l.lane);if(!card)continue;const q=k=>card.querySelector(`[data-k="${k}"]`);
  const pill=q('pill');pill.textContent=(l.task||'-')+(l.n?`  ${l.n}/${l.of}`:'')+(l.device?`  ${l.device}`:'');
  const st=l.state==='running'?(l.phase||'training'):l.state;pill.className='pill '+(st||'');
  const key=(l.run||'')+'/'+(l.video||'');
  if(laneKey[l.lane]!==key){laneKey[l.lane]=key;       // new task or a newer eval: swap the video
   q('box').innerHTML=l.video?`<video autoplay muted loop playsinline controls src="/video/${encodeURIComponent(l.run)}/${l.video}"></video>`
    :`<div class="empty">${l.run?l.task+': waiting for the first evaluation video':'no '+l.lane+' run yet'}</div>`;}
  const e=l.eval;q('cap').innerHTML=e?`<b>${l.task}</b> &middot; eval @ ${e.steps.toLocaleString()} steps${e.passed?' <span class="tag">PASS</span>':''}<br>`+
   `return <b>${e.ep_return.toFixed(0)}</b> &middot; upright <b>${(100*e.upright_frac).toFixed(0)}%</b> &middot; hold <b>${e.best_hold_s.toFixed(1)} s</b> &middot; ends ${(e.ends||[]).join(',')}<br>`+
   `best so far ${l.best==null?'-':l.best.toFixed(0)} &middot; arm max ${(e.max_arm_w??0).toFixed(1)} rad/s &middot; loops ${(e.max_loops??0).toFixed(1)}/3s &middot; jolts ${(e.max_jolts??0).toFixed(0)}/s &middot; cart max ${(e.max_cart_v??0).toFixed(2)} m/s`+
   ((e.flags||[]).length?`<br><span style="color:#f3cf94">${e.flags.join(' &middot; ')}</span>`:'')
   :(l.run?`<b>${l.task}</b> &middot; ${l.run}`:'');}}
async function loop(){await runs();await tick();await lanes();} loop(); setInterval(tick,2000); setInterval(runs,3000); setInterval(lanes,3000);
</script></body></html>"""


def main():
    p = argparse.ArgumentParser(); p.add_argument('--port', type=int, default=8000)
    p.add_argument('--no-browser', action='store_true'); p.add_argument('--no-live', action='store_true')
    p.add_argument('--fps', type=int, default=30, help='live view frame rate (lower = less CPU)')
    a = p.parse_args()
    srv = ThreadingHTTPServer(('127.0.0.1', a.port), H); srv.daemon_threads = True
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    print(f'Dashboard: http://localhost:{a.port}   (Ctrl+C to stop)')
    if not a.no_browser:
        try: webbrowser.open(f'http://localhost:{a.port}')
        except Exception: pass
    try:
        if a.no_live:
            while True: time.sleep(1)
        live_loop(fps=a.fps)
    except KeyboardInterrupt:
        pass


if __name__ == '__main__':
    main()
