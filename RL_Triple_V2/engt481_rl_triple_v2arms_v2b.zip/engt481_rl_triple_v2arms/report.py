"""
Bundle everything needed to diagnose a training session into ONE zip you can hand to Claude.

  python report.py                     newest prefix (from runs/lanes.json) or every run
  python report.py --prefix dbl        all runs named dbl_*
  python report.py --runs a,b          specific runs

Writes runs/<prefix>_report_<time>.zip containing:
  SUMMARY.txt                 machine, settings, per-task results and plain-language behaviour flags
  <run>/config.json, status.json, metrics.csv, diag.jsonl, console.log (tail)
  <run>/trace/*.csv.gz        step-by-step (100 Hz) traces: first, best, last evals + every ~10th
run_all.py builds this automatically when it finishes or is stopped.
"""
import argparse, io, json, os, platform, sys, time, zipfile
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parent
RUNS = ROOT / 'runs'
sys.path.insert(0, str(ROOT))


def machine():
    lines = [f'python {platform.python_version()}  {platform.platform()}  cores {os.cpu_count()}']
    try:
        import torch
        lines.append(f"torch {torch.__version__}  cuda {'yes: ' + torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'no'}")
    except Exception: pass
    for mod in ('mujoco', 'stable_baselines3', 'sb3_contrib', 'gymnasium'):
        try: lines.append(f'{mod} {__import__(mod).__version__}')
        except Exception: lines.append(f'{mod} missing')
    try:
        from pendulum_env import ENV_VERSION
        lines.append(f'env version {ENV_VERSION}')
    except Exception: pass
    return lines


def pick_traces(names, evals, keep=12):
    """First, best, last three and an even spread of the rest."""
    if not names: return []
    by = {e['steps']: e for e in evals}
    steps = [int(n[5:14]) for n in names]
    chosen = {steps[0], *steps[-3:]}
    if evals:
        chosen.add(max(evals, key=lambda e: e['ep_return'])['steps'])
    k = max(1, len(steps) // max(1, keep - len(chosen)))
    chosen |= set(steps[::k])
    return [n for n, s in zip(names, steps) if s in chosen]


def run_summary(d):
    out = []
    try: cfg = json.load(open(d / 'config.json'))
    except Exception: cfg = {}
    try: st = json.load(open(d / 'status.json'))
    except Exception: st = {}
    ev = st.get('evals', [])
    out.append(f"== {d.name}   task {st.get('task', cfg.get('task'))}   algo {cfg.get('algo')}   device {cfg.get('device')}   "
               f"phase {st.get('phase')}   steps {st.get('steps', 0):,}/{st.get('total_steps', 0):,}   "
               f"{st.get('steps_per_s', 0):.0f} st/s   elapsed {st.get('elapsed_s', 0)/60:.1f} min   "
               f"solved_at {st.get('solved_at')}")
    out.append(f"   env_cfg {json.dumps(cfg.get('env_cfg', {}))}   init_from {cfg.get('init_from')}")
    out.append(f"   {'step':>9} {'score':>6} {'up%':>4} {'hold':>5} {'ends':>5} {'arm':>5} {'loops':>5} {'jolt':>4} pass  behaviour")
    for e in ev:
        flags = '; '.join((e.get('diag') or {}).get('flags', []))
        out.append(f"   {e['steps']:>9,} {e['ep_return']:>6.0f} {100*e['upright_frac']:>4.0f} {e['best_hold_s']:>5.1f} "
                   f"{''.join(x[0] for x in e.get('ends', [])):>5} {e.get('max_arm_w', 0):>5.1f} {e.get('max_loops', 0):>5.1f} "
                   f"{e.get('max_jolts', 0):>4.0f} {'Y' if e.get('passed') else ' ':>4}  {flags}")
    # learner health from diag.jsonl
    try:
        recs = [json.loads(l) for l in open(d / 'diag.jsonl') if l.strip()]
        ents = [(r['steps'], r['ent_coef']) for r in recs if 'ent_coef' in r]
        if ents:
            pts = ents[:: max(1, len(ents) // 8)] + [ents[-1]]
            out.append('   entropy coef (exploration): ' + '  '.join(f'{s//1000}k:{v:.3g}' for s, v in pts))
        te = [r for r in recs if 'train_eps' in r]
        if te:
            last = te[-1]['train_eps']
            out.append(f"   training episodes (last 50): ret {last['ret']}  upright {last['upright']}  ends {last['ends']}  "
                       f"jolts {last['jolts']}/s  loops {last['loops']}  cart_v {last['cart_v']}")
        sb = [r['sb3'] for r in recs if r.get('sb3')]
        if sb: out.append('   learner (last): ' + '  '.join(f'{k[6:]} {v:.4g}' for k, v in sb[-1].items()))
    except Exception:
        pass
    return out, ev


def build(run_dirs, out_path):
    lines = ['ENGT481 training report  ' + time.strftime('%Y-%m-%d %H:%M'), *machine(), '']
    for f in ('lanes.json', 'solve_history.json'):
        if (RUNS / f).exists(): lines.append(f'{f}: ' + (RUNS / f).read_text()[:3000].replace('\n', ' '))
    lines.append('')
    z = zipfile.ZipFile(out_path, 'w', zipfile.ZIP_DEFLATED)
    for d in run_dirs:
        s, ev = run_summary(d); lines += s + ['']
        for f in ('config.json', 'status.json', 'metrics.csv', 'diag.jsonl'):
            if (d / f).exists(): z.write(d / f, f'{d.name}/{f}')
        if (d / 'console.log').exists():
            tail = (d / 'console.log').read_text(errors='replace').splitlines()[-400:]
            z.writestr(f'{d.name}/console_tail.log', '\n'.join(tail))
        tr = sorted(p.name for p in (d / 'trace').glob('step_*.csv.gz')) if (d / 'trace').exists() else []
        for n in pick_traces(tr, ev):
            z.write(d / 'trace' / n, f'{d.name}/trace/{n}')
    z.writestr('SUMMARY.txt', '\n'.join(lines))
    z.close()
    return out_path


def select(prefix=None, runs=None):
    if runs:
        return [RUNS / r for r in runs.split(',') if (RUNS / r).is_dir()]
    if prefix is None:
        try: prefix = json.load(open(RUNS / 'lanes.json'))['prefix']
        except Exception: prefix = ''
    return sorted(d for d in RUNS.iterdir() if d.is_dir() and d.name.startswith(prefix) and (d / 'status.json').exists())


def make(prefix=None, runs=None):
    ds = select(prefix, runs)
    tag = prefix or (json.load(open(RUNS / 'lanes.json')).get('prefix') if (RUNS / 'lanes.json').exists() else 'all')
    out = RUNS / f'{tag}_report_{time.strftime("%Y%m%d-%H%M")}.zip'
    return build(ds, out), len(ds)


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--prefix', default=None); p.add_argument('--runs', default=None)
    a = p.parse_args()
    out, n = make(a.prefix, a.runs)
    print(f'Report ({n} runs): {out}')
    print('Upload that zip to Claude.')
