"""
Behaviour logging and automatic diagnosis.

train.py records the first episode of every evaluation step-by-step (100 Hz) into
runs/<run>/trace/step_XXXXXXXXX.csv.gz and a one-line diagnosis into status.json.
report.py bundles everything into one zip you can hand over for analysis.
"""
import csv, gzip, io
import numpy as np

FACTORS = ['up', 'centered', 'calm']      # the better version's reward: up * centered * calm - effort


def trace_header(n_arms):
    return (['t', 'x', 'xd', 'v_cmd', 'action']
            + [f'th{i+1}_deg' for i in range(n_arms)] + [f'w{i+1}' for i in range(n_arms)]
            + ['r'] + FACTORS + ['jolt_rate', 'turns', 'effort', 'upright'])


def trace_row(env, action):
    th, w = env.angles()
    L = getattr(env, 'last', {}) or {}
    thd = np.degrees((th + np.pi) % (2 * np.pi) - np.pi)
    return ([round(env.steps * env.cfg['ctrl_dt'], 2), round(float(env.data.qpos[0]), 4), round(float(env.data.qvel[0]), 3),
             round(float(env.v_cmd), 3), round(float(np.asarray(action).reshape(-1)[0]), 3)]
            + [round(float(v), 1) for v in thd] + [round(float(v), 2) for v in w]
            + [round(float(L.get('r', 0)), 4)] + [round(float(L.get(k, 0)), 3) for k in FACTORS]
            + [int(L.get('jolt_rate', 0)), round(float(L.get('turns', 0)), 2), round(float(L.get('effort', 0)), 4),
               int(env.is_upright())])


def save_trace(path, header, rows):
    buf = io.StringIO(); wr = csv.writer(buf); wr.writerow(header); wr.writerows(rows)
    tmp = str(path) + '.tmp'
    with gzip.open(tmp, 'wt', newline='') as f: f.write(buf.getvalue())
    import os
    os.replace(tmp, path)


def load_trace(path):
    with gzip.open(path, 'rt') as f:
        rd = csv.reader(f); h = next(rd); rows = [list(map(float, r)) for r in rd]
    return h, np.array(rows) if rows else np.zeros((0, len(h)))


def analyse(header, rows, task, end='time', dt=0.01):
    """Numbers + plain-language flags describing what the pendulum did in one episode."""
    if len(rows) == 0: return dict(flags=['empty trace'])
    c = {k: i for i, k in enumerate(header)}
    col = lambda k: rows[:, c[k]]
    n_arms = sum(1 for k in header if k.startswith('th'))
    T = len(rows) * dt
    a = col('action'); da = np.diff(a) if len(a) > 1 else np.zeros(1)
    # command reversals: direction of change flips with a meaningful step
    big = np.abs(da) > 0.1; sgn = np.sign(da[big])
    reversals = int(np.sum(sgn[1:] != sgn[:-1])) if len(sgn) > 1 else 0
    freq = 0.0
    if len(a) > 32:
        spec = np.abs(np.fft.rfft(a - a.mean())); f = np.fft.rfftfreq(len(a), dt)
        freq = float(f[1 + np.argmax(spec[1:])])
    up = col('upright') > 0.5
    t_up = float(np.argmax(up) * dt) if up.any() else None
    d = dict(
        seconds=round(T, 2), end=end, upright_frac=round(float(up.mean()), 3), t_first_upright=t_up,
        score=round(float(col('r').sum()), 1),
        action_reversals_per_s=round(reversals / T, 1), action_rms_change=round(float(np.sqrt(np.mean(da ** 2))), 3),
        action_saturated_frac=round(float(np.mean(np.abs(a) > 0.95)), 3), action_dominant_hz=round(freq, 1),
        cart_x_range=[round(float(col('x').min()), 3), round(float(col('x').max()), 3)],
        cart_abs_x_mean=round(float(np.abs(col('x')).mean()), 3), cart_v_max=round(float(np.abs(col('xd')).max()), 2),
        jolt_rate_max=int(col('jolt_rate').max()), jolt_rate_mean=round(float(col('jolt_rate').mean()), 1),
        turns_max=round(float(col('turns').max()), 2),
        arm_w_max=[round(float(np.abs(col(f'w{i+1}')).max()), 1) for i in range(n_arms)],
        factor_mean={k: round(float(col(k).mean()), 3) for k in header if k in FACTORS},
    )
    if up.any():
        d['factor_mean_while_up'] = {k: round(float(col(k)[up].mean()), 3) for k in header if k in FACTORS and k != 'up'}
        # small wobble while balancing
        d['upright_angle_rms_deg'] = [round(float(np.sqrt(np.mean(col(f'th{i+1}_deg')[up] ** 2))), 2) for i in range(n_arms)]
    flags = []
    if end == 'rail': flags.append('hit the rail end')
    if end == 'stall': flags.append('arms dragged the cart past the speed limit (stall)')
    if end == 'fell': flags.append('fell over')
    if d['jolt_rate_max'] > 6 or d['action_reversals_per_s'] > 15:
        flags.append(f"CHATTER: cart command reverses {d['action_reversals_per_s']}/s "
                     f"(peak {d['jolt_rate_max']} hard reversals/s, dominant {d['action_dominant_hz']} Hz)")
    if d['action_saturated_frac'] > 0.4:
        flags.append(f"bang-bang: command at its limit {100*d['action_saturated_frac']:.0f}% of the time")
    if d['turns_max'] > 1.25: flags.append(f"FAN-BLADING: an arm made {d['turns_max']} turns within 3 s")
    if task.endswith('swingup') and not up.any():
        flags.append('never reached upright' + (f", best tip height factor {col('up').max():.2f}"))
    if t_up is not None and task.endswith('swingup') and t_up > 4:
        flags.append(f'slow swing-up: first upright at {t_up:.1f} s')
    if d['cart_abs_x_mean'] > 0.2: flags.append(f"cart drifts off-centre (mean |x| {d['cart_abs_x_mean']} m)")
    if up.any():
        fm = d['factor_mean_while_up']; low = min(fm, key=fm.get)
        if fm[low] < 0.8: flags.append(f"while up, most reward is lost to '{low}' (mean {fm[low]})")
        if max(d['upright_angle_rms_deg']) > 5: flags.append(f"wobbly balance: angle rms {d['upright_angle_rms_deg']} deg")
    d['flags'] = flags or ['no problems detected']
    return d


def one_line(d):
    return '; '.join(d.get('flags', []))
