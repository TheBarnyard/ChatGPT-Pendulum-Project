"""
Write an MP4 of a saved policy (also used by train.py / run_all.py for the evaluation videos).

  python record.py --run <run name>                    # best.zip -> runs/<run>/replay_best.mp4
  python record.py --run <run> --policy latest --seconds 30 --episodes 3
  python record.py --task triple_balance --lqr         # LQR reference video
  python record.py --task triple_swingup --passive     # no controller, just physics
"""
import argparse, os, sys
from pathlib import Path
import numpy as np

os.environ.setdefault('MUJOCO_GL', 'egl' if sys.platform.startswith('linux') else 'glfw')
from pendulum_env import CartPendulumEnv
from common import RUNS, resolve_run, run_config, load_policy, policy_step


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--run', default=None, help="run name or folder (default: newest run)")
    p.add_argument('--policy', default='best', help='best | latest | path to .zip')
    p.add_argument('--task', default=None, help="override the run's task (e.g. a swing-up policy from upright)")
    p.add_argument('--lqr', action='store_true', help='record the LQR instead of a learned policy')
    p.add_argument('--passive', action='store_true', help='no controller')
    p.add_argument('--out', default=None)
    p.add_argument('--seconds', type=float, default=10.0, help='length of each episode')
    p.add_argument('--episodes', type=int, default=1)
    p.add_argument('--seed', type=int, default=10_000)
    p.add_argument('--width', type=int, default=1280)
    p.add_argument('--height', type=int, default=720)
    p.add_argument('--label', default=None)
    a = p.parse_args()

    run_dir, cfg, policy = None, {}, None
    if not (a.lqr or a.passive):
        run_dir = resolve_run(a.run); cfg = run_config(run_dir)
    task = a.task or cfg.get('task') or 'triple_swingup'
    ecfg = {k: v for k, v in cfg.get('env_cfg', {}).items() if k != 'upright_start_prob'}
    env = CartPendulumEnv(task, width=a.width, height=a.height, **ecfg)
    env.max_steps = int(round(a.seconds / env.cfg['ctrl_dt']))

    if a.lqr:
        from watch import LQR
        policy, label = LQR(env), f'{task}  LQR'
        out = Path(a.out or RUNS / f'lqr_{task}.mp4')
    elif a.passive:
        label, out = f'{task}  passive', Path(a.out or RUNS / f'passive_{task}.mp4')
    else:
        pp = run_dir / f'{a.policy}.zip' if a.policy in ('best', 'latest') else Path(a.policy)
        if not pp.exists():
            raise SystemExit(f'Policy not found: {pp}')
        policy = load_policy(pp, cfg['algo'])
        ps = policy_step(run_dir, pp)
        label = f"{run_dir.name}  [{pp.name}]" + (f"  step {ps:,}" if ps is not None else '')
        out = Path(a.out or run_dir / f'replay_{pp.stem}.mp4')
    label = a.label or label

    frames = []
    for ep in range(a.episodes):
        obs, _ = env.reset(seed=a.seed + ep)
        if hasattr(policy, 'v'): policy.v = 0.0
        done = False
        while not done:
            act = policy.predict(obs, deterministic=True)[0] if policy is not None else np.zeros(1)
            obs, r, term, trunc, info = env.step(act)
            done = term or trunc
            if env.steps % 2 == 0 or done:                       # 50 fps
                th, _ = env.angles()
                hud = [label, f'episode {ep + 1}   t {env.steps*0.01:5.2f} s   x {env.data.qpos[0]*1000:+6.0f} mm',
                       'theta ' + '  '.join(f'{np.degrees((t+np.pi)%(2*np.pi)-np.pi):+7.1f}' for t in th) + ' deg',
                       f'return {env.ep_return:7.1f}   hold {env.hold*0.01:4.1f} s']
                frames.append(env.render(hud))
        if done and info:
            print(f"episode {ep + 1}: return {info['ep_return']:.1f}  upright {100*info['upright_frac']:.0f}%  "
                  f"longest hold {info['best_hold_s']:.1f}s  end={info['end']}")
        frames += [frames[-1]] * 25                               # half-second pause between episodes
    env.close()

    import imageio.v2 as imageio
    out.parent.mkdir(parents=True, exist_ok=True)
    tmp = str(out).replace('.mp4', '.tmp.mp4')
    imageio.mimsave(tmp, frames, fps=50, macro_block_size=1, quality=7)
    os.replace(tmp, out)
    print(f'Video: {out}')


if __name__ == '__main__':
    main()
