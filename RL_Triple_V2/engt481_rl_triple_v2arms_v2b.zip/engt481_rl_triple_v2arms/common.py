"""Shared helpers for watch.py / record.py / dashboard.py."""
import json, os, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RUNS = ROOT / 'runs'


def resolve_run(run):
    """'latest', a run folder name, or a path -> Path to the run folder."""
    if run in (None, 'latest'):
        f = RUNS / 'LATEST'
        if not f.exists():
            raise SystemExit('No runs yet. Start one with:  python run_all.py')
        run = f.read_text().strip()
    p = Path(run)
    if not p.exists():
        p = RUNS / run
    if not p.exists():
        raise SystemExit(f'Run not found: {run}')
    return p


def run_config(run_dir):
    cfg = json.load(open(run_dir / 'config.json'))
    cfg.setdefault('env_cfg', {}).setdefault('model', 'model')
    cfg['env_cfg'].setdefault('action_mode', 'velocity')
    cfg.setdefault('algo', 'sac')
    return cfg


def load_policy(path, algo):
    from stable_baselines3 import SAC, PPO
    if algo == 'tqc':
        from sb3_contrib import TQC as Algo
    else:
        Algo = SAC if algo == 'sac' else PPO
    for _ in range(5):            # the trainer may be mid-write; retry briefly
        try:
            return Algo.load(str(path), device='cpu')
        except Exception:
            time.sleep(0.5)
    return Algo.load(str(path), device='cpu')


def newest_policy(run_dir, prefer='latest'):
    for name in ([prefer] if prefer != 'latest' else []) + ['latest.zip', 'best.zip']:
        p = run_dir / name if name.endswith('.zip') else Path(name)
        if p.exists():
            return p
    return None


def policy_step(run_dir, policy_path):
    """Training step at which a policy file was saved (for labels)."""
    import re
    m = re.search(r'step_(\d+)', str(policy_path))
    if m: return int(m.group(1))
    try:
        if Path(policy_path).name == 'latest.zip':
            return json.load(open(run_dir / 'latest.json'))['steps']
        if Path(policy_path).name == 'best.zip':
            st = json.load(open(run_dir / 'status.json'))
            best = max(st.get('evals', []), key=lambda e: e['ep_return'])
            return best['steps']
    except Exception:
        pass
    return None
