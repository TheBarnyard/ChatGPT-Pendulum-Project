"""
Train the triple balance and the triple swing-up (V2 arms, arm 3 = 300 mm).

  python run_all.py --dashboard

At start-up it benchmarks CPU vs GPU (every time, about a minute), then runs two lanes:
  balance lane  (the SLOWER device):  triple_balance            (stops after 3 passes in a row)
  swing-up lane (the FASTER device):  triple_swingup            (stops after 5 passes in a row)
triple_swingup warm-starts from the triple_balance best.zip, so it waits for it to finish.
No GPU: both lanes run on the CPU.

The window shows the two lanes side by side (left = balance, right = swing-up): progress bar, speed,
ETAs and every evaluation. Full per-task logs -> runs/<run>/console.log
Each task stops by itself once solved. Best replay of each task -> runs/<prefix>_best_videos/<n>_<task>.mp4
runs/lanes.json tells the dashboard which task each lane is on (its two video panels follow it).

Options:
  --only triple_swingup                     run a subset
  --serial                                  old behaviour: one task at a time, in order (one column)
  --swingup-from <policy.zip>               warm start for triple_swingup instead of triple_balance
  --refresh 10                              seconds between progress rows
  extra train.py arguments after  --        e.g.  -- --randomize
"""
import argparse, json, os, shutil, subprocess, sys, textwrap, threading, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RUNS = ROOT / 'runs'
ORDER = ['triple_balance', 'triple_swingup']
PARENT = {'triple_swingup': 'triple_balance'}
BALANCE = [t for t in ORDER if t.endswith('balance')]
SWING = [t for t in ORDER if t.endswith('swingup')]

p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
p.add_argument('--prefix', default='tri')
p.add_argument('--only', default=None)
p.add_argument('--serial', action='store_true')
p.add_argument('--dashboard', action='store_true')
p.add_argument('--swingup-from', default=None, help='warm start for triple_swingup instead of triple_balance')
p.add_argument('--video-seconds', type=float, default=10)
p.add_argument('--refresh', type=float, default=10)
a, extra = p.parse_known_args()
extra = [x for x in extra if x != '--']
only = set(a.only.split(',')) if a.only else None
names = {t: f'{a.prefix}_{ORDER.index(t)+1}_{t}' for t in ORDER}
best_dir = RUNS / f'{a.prefix}_best_videos'; best_dir.mkdir(parents=True, exist_ok=True)
done = {t: threading.Event() for t in ORDER}
results, lock = {}, threading.Lock()


def width():
    return max(shutil.get_terminal_size((120, 20)).columns - 1, 40)


def say(line):
    """Full-width line (used before/after the two-column view)."""
    w = width()
    with lock:
        print(line if len(line) <= w else line[:w - 1] + '~', flush=True)


def fmt_t(s):
    if s is None: return '--'
    s = int(max(s, 0)); h, r = divmod(s, 3600); m, s = divmod(r, 60)
    return f'{h:d}:{m:02d}:{s:02d}'


# ------------------------------------------------------------------ device plan
if a.serial:
    lanes = [('serial', None, list(ORDER))]
else:
    import torch
    if torch.cuda.is_available():
        say('Benchmarking CPU vs GPU (about a minute; runs every time you start)...')
        sys.path.insert(0, str(ROOT))
        from train import benchmark
        res = benchmark('triple_swingup')
        strong = max(res, key=res.get); weak = 'cpu' if strong == 'cuda' else 'cuda'
        say(f'  swing-up lane -> {strong} ({res[strong]:.0f} st/s)   balance lane -> {weak} ({res[weak]:.0f} st/s)')
    else:
        strong = weak = 'cpu'
        say('No CUDA GPU found: both lanes run on the CPU, in parallel.')
    lanes = [('balance', weak, BALANCE), ('swing', strong, SWING)]
TITLE = {'balance': 'BALANCE', 'swing': 'SWING-UP', 'serial': 'ALL TASKS'}

# per-lane state shared by the workers, the screen and the dashboard (runs/lanes.json)
state = {l: dict(lane=l, device=d or 'auto', task=None, run=None, state='starting', n=0,
                 of=len([t for t in ts if not only or t in only]), events=[], seen=0)
         for l, d, ts in lanes}


def write_lanes():
    doc = dict(prefix=a.prefix, pid=os.getpid(), updated=time.time(),
               lanes=[{k: v for k, v in state[l].items() if k in ('lane', 'device', 'task', 'run', 'state', 'n', 'of')} for l, _, _ in lanes])
    try:
        tmp = RUNS / 'lanes.tmp.json'; json.dump(doc, open(tmp, 'w'), indent=1)
        for _ in range(20):
            try: os.replace(tmp, RUNS / 'lanes.json'); break
            except PermissionError: time.sleep(0.05)
    except Exception:
        pass


def event(lane, *lines):
    with lock:
        state[lane]['events'].extend(lines)


# ------------------------------------------------------------------ two-column ASCII screen
def pack(fields, w):
    """Greedy-wrap fields (separated by 2 spaces) into lines no wider than w. Lines starting with
    '  ' continue the previous item."""
    out, cur = [], ''
    for f in fields:
        f = f if len(f) <= w else f[:w - 1] + '~'
        if not cur: cur = f
        elif len(cur) + 2 + len(f) <= w: cur += '  ' + f
        else: out.append(cur); cur = '   ' + f.lstrip() if len(f) + 3 <= w else f
    if cur: out.append(cur)
    return out


def cols():
    n = len(lanes)
    return max((width() - 1 - 3 * n) // n, 20)


def header():
    c = cols(); parts = []
    for l, _, _ in lanes:
        s = state[l]
        t = f"[ {TITLE[l]} | {s['device']} ]" + (f"=[ {s['task']} {s['n']}/{s['of']} ]" if s['task'] else '')
        parts.append(('=' + t + '=' * c)[:c + 2])
    return '+' + '+'.join(parts) + '+'


def rows(cells):
    c = cols(); h = max(len(x) for x in cells)
    out = []
    for i in range(h):
        out.append('| ' + ' | '.join((x[i] if i < len(x) else '').ljust(c) for x in cells) + ' |')
    return out


def bar(pct, n):
    k = int(round(n * min(max(pct, 0), 100) / 100))
    return '[' + '#' * k + '.' * (n - k) + ']'


def progress_cells(l):
    s = state[l]; c = cols()
    if s['state'] != 'running' or not s['run']:
        return []
    f = RUNS / s['run'] / 'status.json'
    try: st = json.load(open(f))
    except Exception:
        if s.get('said') == s['run']: return []
        s['said'] = s['run']; return [f"  {s['task']}: starting..."]
    ev_lines = []
    evs = st.get('evals', [])
    for ev in evs[s['seen']:]:
        tag = (f"PASS {ev.get('streak', 0)}/{st.get('patience', 3)}  " if ev.get('passed') else '') + \
              ('BEST' if ev.get('best') else '')
        ends = ''.join(e[0] for e in ev.get('ends', []))
        ev_lines += pack([f"> eval {ev['steps']:,}", tag.strip()] if tag.strip() else [f"> eval {ev['steps']:,}"], c)
        ev_lines += pack([f"   ret {ev['ep_return']:.0f}", f"up {100*ev['upright_frac']:.0f}%",
                          f"hold {ev['best_hold_s']:.1f}s", f"ends {ends}"], c)
        ev_lines += pack([f"   arm {ev.get('max_arm_w', 0):.1f} rad/s", f"loops {ev.get('max_loops', 0):.1f}",
                          f"jolts {ev.get('max_jolts', 0):.0f}/s", f"cart {ev.get('max_cart_v', 0):.2f} m/s", f"acc {ev.get('max_cart_a', 0):.0f} m/s2"], c)
        for fl in (ev.get('diag') or {}).get('flags', []):
            if fl == 'no problems detected': continue
            for i, ln in enumerate(textwrap.wrap(fl, max(c - 5, 10))):
                ev_lines.append(('   ! ' if i == 0 else '     ') + ln)
    s['seen'] = len(evs)
    if not ev_lines and st['steps'] == s.get('last_steps') and s.get('last_phase') == st.get('phase'):
        return []                                               # nothing new: don't repeat the row
    s['last_steps'], s['last_phase'] = st['steps'], st.get('phase')
    pct = 100 * st['steps'] / max(st['total_steps'], 1)
    txt = f" {pct:5.1f}%  {st['steps']:,}/{st['total_steps']:,}"
    n = max(min(c - len(txt) - 2, 30), 5)
    lines = [bar(pct, n) + txt]
    lines += pack([f"{st.get('steps_per_s', 0):.0f} st/s", f"ETA {fmt_t(st.get('eta_likely_s'))}",
                   f"max {fmt_t(st.get('eta_s'))}", f"pass {st.get('pass_streak', 0)}/{st.get('patience', 3)}"]
                  + ([f"ret {st['train_return']:.0f}"] if st.get('train_return') is not None else []), c)
    if st.get('phase') == 'evaluating': lines[-1:] = pack([lines[-1], '(evaluating)'], c)
    return ev_lines + lines


def screen(threads):
    last_hdr, tick = None, 0
    while True:
        alive = any(th.is_alive() for th in threads)
        time.sleep(0.5 if not alive else 0)
        with lock:
            key = tuple((state[l]['task'], state[l]['state']) for l, _, _ in lanes)
        cells = []
        for l, _, _ in lanes:
            with lock:
                evs, state[l]['events'] = state[l]['events'], []
            c = cols()
            cell = []
            for e in evs: cell += pack([e], c)
            cells.append(cell + progress_cells(l))
        write_lanes()
        if any(cells):
            with lock:
                if key != last_hdr or tick % 15 == 0:
                    print(header(), flush=True); last_hdr = key
                for r in rows(cells): print(r, flush=True)
            tick += 1
        if not alive:
            with lock: print(header().replace('=', '-'), flush=True)
            return
        t_end = time.time() + a.refresh
        while time.time() < t_end and any(th.is_alive() for th in threads):
            time.sleep(0.25)


# ------------------------------------------------------------------ workers
def run_task(lane, device, task):
    if only and task not in only:
        done[task].set(); return
    s = state[lane]
    n_thr = max(1, (os.cpu_count() or 2) // len(lanes))          # split the CPU cores between the lanes
    cmd = [sys.executable, str(ROOT / 'train.py'), '--task', task, '--name', names[task], '--print-every', '10',
           '--threads', str(n_thr)] + extra
    if device: cmd += ['--device', device]
    if task == 'triple_swingup' and a.swingup_from:
        cmd += ['--init-from', a.swingup_from]
    elif task in PARENT and (not only or PARENT[task] in only):
        if not done[PARENT[task]].is_set():
            s['state'] = 'waiting'
            event(lane, f"~ {task}: waiting for {PARENT[task]}", "   to finish (warm start)...")
        done[PARENT[task]].wait()
        best = RUNS / names[PARENT[task]] / 'best.zip'
        if best.exists(): cmd += ['--init-from', str(best)]
    run = RUNS / names[task]; run.mkdir(parents=True, exist_ok=True)
    s.update(task=task, run=names[task], state='running', n=s['n'] + 1, seen=0)
    event(lane, f"* START {task} on {device or 'auto'}", f"   log: runs/{names[task]}/console.log")
    t0 = time.time()
    with open(run / 'console.log', 'w') as log:
        rc = subprocess.call(cmd, stdout=log, stderr=subprocess.STDOUT)
    mins = (time.time() - t0) / 60
    results[task] = (lane, device, mins, rc)
    s['state'] = 'finishing'
    if rc == 0:
        out = best_dir / f'{ORDER.index(task)+1}_{task}.mp4'
        subprocess.call([sys.executable, str(ROOT / 'record.py'), '--run', names[task], '--policy', 'best',
                         '--seconds', str(a.video_seconds), '--out', str(out),
                         '--label', f'{task}  best policy  ({names[task]})'],
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        solved = ''
        try: solved = 'SOLVED' if json.load(open(run / 'status.json')).get('solved_at') else 'budget used'
        except Exception: pass
        event(lane, f"# DONE {task}  {mins:.1f} min  {solved}", f"   best replay -> {out.name}")
    else:
        event(lane, f"! FAILED {task} (exit {rc})", f"   see runs/{names[task]}/console.log")
    done[task].set()


def lane_worker(lane, device, tasks):
    for t in tasks:
        run_task(lane, device, t)
    state[lane]['state'] = 'done'
    event(lane, '== lane finished ==')


if a.dashboard:
    subprocess.Popen([sys.executable, str(ROOT / 'dashboard.py')])
t_all = time.time()
threads = [threading.Thread(target=lane_worker, args=l, daemon=True) for l in lanes]
for th in threads: th.start()
try:
    screen(threads)
except KeyboardInterrupt:
    say('Stopping... (each training saves latest.zip)')
    try:
        t_end = time.time() + 30                      # give each trainer time to save latest.zip
        while any(th.is_alive() for th in threads) and time.time() < t_end:
            time.sleep(0.25)
    except KeyboardInterrupt:
        pass
for l, _, _ in lanes: state[l]['state'] = 'done'
write_lanes()

w = min(width(), 72)
say('+' + '-' * (w - 2) + '+')
say('| ' + 'SUMMARY'.ljust(w - 4) + ' |')
say('+' + '-' * (w - 2) + '+')
for t in ORDER:
    if t in results:
        lane, dev, mins, rc = results[t]
        say('| ' + f'{t:16s} {lane:8s} {str(dev):5s} {mins:7.1f} min   exit {rc}'.ljust(w - 4) + ' |')
say('| ' + f'total wall time  {(time.time() - t_all) / 60:.1f} min'.ljust(w - 4) + ' |')
say('+' + '-' * (w - 2) + '+')
say(f'Best replays: {best_dir}')
try:
    sys.path.insert(0, str(ROOT)); import report
    out, n = report.make(a.prefix)
    print(f'Diagnostic report ({n} runs):\n  {out}', flush=True)
    say('  -> upload that zip to Claude to have the behaviour analysed')
except Exception as e:
    say(f'(report failed: {e}; run  python report.py --prefix {a.prefix})')
