"""
TURBO: train the triple swing-up as fast as this PC allows, safely.

  python turbo.py --dashboard
  python turbo.py --from runs\\tri_1_triple_balance\\best.zip --seeds 2

What it does
  1. Benchmarks a few learner layouts on this PC (about 20 s each): CPU and, if there is a CUDA GPU, GPU
     with more parallel envs and bigger batches. Every layout feeds the learner the same number of
     samples per collected step (gradient steps x batch / envs = 512, like the normal run), so it learns
     from each step about as hard; only the split into fewer, bigger updates changes.
  2. Starts --seeds independent swing-up runs (default 2) with the fastest layout, warm-started from the
     balance policy. RL swing-ups are seed-dependent, so 2 tries in parallel usually beat 1.
     The first run that solves (5 passing evals in a row) stops the others.
  3. Safety: trainers run at BELOW-NORMAL priority (YouTube etc. stay smooth), --reserve-cores (default 2)
     cores are left free, evals/videos/checkpoints only every 200k steps to limit disk use.

Ctrl+C stops everything; every run keeps latest.zip and best.zip. Runs are runs/<prefix>_s<n>/.
"""
import argparse, json, math, os, subprocess, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RUNS = ROOT / 'runs'
TASK = 'triple_swingup'

p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
p.add_argument('--from', dest='init_from', default=str(RUNS / 'tri_1_triple_balance' / 'best.zip'),
               help='warm start (default runs/tri_1_triple_balance/best.zip; "none" = from scratch)')
p.add_argument('--seeds', type=int, default=2, help='parallel independent runs (default 2)')
p.add_argument('--prefix', default='turbo')
p.add_argument('--reserve-cores', type=int, default=2, help='CPU cores left free for you (default 2)')
p.add_argument('--layout', default=None, help='skip the benchmark, e.g. "cuda,32,8,2048" = device,envs,gradient steps,batch')
p.add_argument('--bench-seconds', type=float, default=20)
p.add_argument('--steps', type=int, default=60_000_000)
p.add_argument('--eval-every', type=int, default=200_000)
p.add_argument('--dashboard', action='store_true')
p.add_argument('--resume', action='store_true',
               help='continue the paused runs <prefix>_s1, _s2, ... exactly where they stopped (no benchmark)')
p.add_argument('--variants', default='accel18,smooth',
               help='per seed, cycled: accel18 (cart acceleration capped at 18 m/s^2) | smooth (no cap, rewarded '
                    'for gentle smooth acceleration) | energy | energy-spin | height | plain')
a, extra = p.parse_known_args()
extra = [x for x in extra if x != '--']
RUNS.mkdir(exist_ok=True)
cores = os.cpu_count() or 4
usable = max(1, cores - a.reserve_cores)


def lower_priority():
    """Child-process flags/hooks so the trainers yield to anything you do on the PC."""
    if os.name == 'nt':
        return dict(creationflags=getattr(subprocess, 'BELOW_NORMAL_PRIORITY_CLASS', 0))
    return dict(preexec_fn=lambda: os.nice(10))


def bench(layouts, seconds):
    """Steps/s of the real SAC learner for each (device, envs, gradient_steps, batch), in a child process each
    (clean torch state, below-normal priority)."""
    code = r'''
import sys, time, json
sys.path.insert(0, sys.argv[1])
import torch
dev, envs, gs, bs, secs, thr = sys.argv[2], int(sys.argv[3]), int(sys.argv[4]), int(sys.argv[5]), float(sys.argv[6]), int(sys.argv[7])
torch.set_num_threads(thr)
from stable_baselines3.common.vec_env import DummyVecEnv
from stable_baselines3.common.callbacks import BaseCallback
from pendulum_env import make_env
from train import build_model
venv = DummyVecEnv([make_env("triple_swingup", i, 0, train_mode=True) for i in range(envs)])
m = build_model("sac", venv, dev, gs, bs, learning_starts=2000)
class T(BaseCallback):
    def _on_step(s):
        if s.num_timesteps >= 2000 + 4 * envs and not hasattr(s, "t0"):
            s.t0 = time.time(); s.n0 = s.num_timesteps
        return not (hasattr(s, "t0") and time.time() - s.t0 > secs)
cb = T(); m.learn(total_timesteps=10**9, callback=cb)
print("RESULT", (cb.num_timesteps - cb.n0) / (time.time() - cb.t0))
'''
    res = {}
    for L in layouts:
        dev, envs, gs, bs = L
        thr = max(1, usable // max(1, a.seeds))
        try:
            out = subprocess.run([sys.executable, '-c', code, str(ROOT), dev, str(envs), str(gs), str(bs),
                                  str(seconds), str(thr)], capture_output=True, text=True, timeout=seconds * 6 + 120,
                                 **lower_priority())
            sps = float([ln for ln in out.stdout.splitlines() if ln.startswith('RESULT')][-1].split()[1])
        except Exception as e:
            print(f'  {dev:4s} envs {envs:3d}  grad {gs:2d}  batch {bs:5d}:  failed ({str(e)[:60]})', flush=True)
            continue
        res[L] = sps
        print(f'  {dev:4s} envs {envs:3d}  grad {gs:2d}  batch {bs:5d}:  {sps:6.0f} st/s', flush=True)
    return res


def has_cuda():
    try:
        out = subprocess.run([sys.executable, '-c', 'import torch; print(torch.cuda.is_available())'],
                             capture_output=True, text=True, timeout=120)
        return out.stdout.strip().endswith('True')
    except Exception:
        return False


# ------------------------------------------------------------------ 1. pick the layout
resume_runs = sorted(RUNS.glob(f'{a.prefix}_s*')) if a.resume else []
if a.resume:
    resume_runs = [r for r in resume_runs if (r / 'latest.zip').exists() and (r / 'config.json').exists()]
    if not resume_runs:
        raise SystemExit(f'No runs/{a.prefix}_s*/latest.zip to resume.')
    c = json.load(open(resume_runs[0] / 'config.json'))
    layout = (c.get('device', 'cpu'), c['envs'], c['gradient_steps'], c['batch_size'])
    a.seeds = len(resume_runs)
    print(f'Resuming {a.seeds} runs: ' + ', '.join(r.name for r in resume_runs), flush=True)
elif a.layout:
    d, e, g, b = a.layout.split(',')
    layout = (d, int(e), int(g), int(b))
else:
    cands = [('cpu', 8, 8, 512), ('cpu', 16, 8, 1024)]
    if has_cuda():
        cands += [('cuda', 16, 8, 1024), ('cuda', 32, 8, 2048), ('cuda', 64, 8, 4096)]
    print(f'Benchmarking {len(cands)} layouts, {a.bench_seconds:.0f} s each ({cores} cores, '
          f'{a.reserve_cores} kept free, {a.seeds} parallel runs planned)...', flush=True)
    res = bench(cands, a.bench_seconds)
    if not res:
        raise SystemExit('Benchmark failed for every layout; run  python train.py --task triple_swingup  to see the error.')
    layout = max(res, key=res.get)
    base = res.get(('cpu', 8, 8, 512))
    if base and res[layout] < 1.15 * base:     # not clearly faster: keep the layout the normal run uses
        layout = ('cpu', 8, 8, 512)
    print(f'Layout: {layout[0]}, {layout[1]} envs, {layout[2]} gradient steps, batch {layout[3]}'
          + (f'  ({res[layout] / base:.1f}x the normal layout)' if base else ''), flush=True)

dev, envs, gs, bs = layout
init = None if a.init_from.lower() == 'none' else a.init_from
if init and not a.resume and not Path(init).exists():
    raise SystemExit(f'Warm start not found: {init}\n  give it with --from <best.zip>, or --from none')
thr = max(1, usable // a.seeds - (0 if dev == 'cuda' else 1))

# ------------------------------------------------------------------ 2. start the runs
VARIANT = {'accel18': ['--reward', 'energy', '--cart-accel-limit', '18'],
           'smooth': ['--reward', 'energy', '--smooth-reward'],
           'energy': ['--reward', 'energy'], 'energy-spin': ['--reward', 'energy', '--spin-penalty', '0.01'],
           'height': ['--reward', 'height'], 'plain': ['--reward', 'plain']}
variants = [v.strip() for v in a.variants.split(',') if v.strip()]
procs, names, varof = [], [], {}
def variant_of(cfg):
    e = cfg.get('env_cfg', {})
    if e.get('cart_accel_limit'): return f"accel{e['cart_accel_limit']:g}"
    if e.get('smooth_reward'): return 'smooth'
    return e.get('reward', 'plain') + ('-spin' if e.get('spin_penalty') else '')


for s in range(1, a.seeds + 1):
    if a.resume:
        run = resume_runs[s - 1]; name = run.name
        (run / 'STOP').unlink(missing_ok=True)
        var = variant_of(json.load(open(run / 'config.json')))
        cmd = [sys.executable, str(ROOT / 'train.py'), '--resume', name, '--threads', str(thr), '--print-every', '30']
        log = open(run / 'console.log', 'a')
        procs.append(subprocess.Popen(cmd, stdout=log, stderr=subprocess.STDOUT, cwd=str(ROOT), **lower_priority()))
        names.append(name); varof[name] = var
        print(f'Resumed {name}: {var}   log: runs/{name}/console.log', flush=True)
        continue
    var = variants[(s - 1) % len(variants)]
    name = f'{a.prefix}_s{s}'
    run = RUNS / name; run.mkdir(parents=True, exist_ok=True)
    (run / 'STOP').unlink(missing_ok=True)
    cmd = [sys.executable, str(ROOT / 'train.py'), '--task', TASK, '--name', name, '--device', dev,
           '--envs', str(envs), '--gradient-steps', str(gs), '--batch-size', str(bs), '--threads', str(thr),
           '--steps', str(a.steps), '--eval-every', str(a.eval_every), '--seed', str(1000 * s),
           '--print-every', '30'] + VARIANT[var] + (['--init-from', init] if init else []) + extra
    log = open(run / 'console.log', 'w')
    procs.append(subprocess.Popen(cmd, stdout=log, stderr=subprocess.STDOUT, cwd=str(ROOT), **lower_priority()))
    names.append(name); varof[name] = var
    print(f'Started {name}: {var}, {dev}, {envs} envs, {thr} threads   log: runs/{name}/console.log', flush=True)
if a.dashboard:
    subprocess.Popen([sys.executable, str(ROOT / 'dashboard.py')], **lower_priority())


def status(name):
    try:
        return json.load(open(RUNS / name / 'status.json'))
    except Exception:
        return {}


def write_lanes(best):
    bal = Path(init).parent.name if init and Path(init).parent.parent == RUNS else None
    doc = dict(prefix=a.prefix, pid=os.getpid(), updated=time.time(), lanes=[
        dict(lane='balance', device=None, task='triple_balance', run=bal, state='done', n=1, of=1),
        dict(lane='swing', device=dev, task=TASK, run=best, state='running', n=1, of=1)])
    try:
        tmp = RUNS / 'lanes.tmp.json'; json.dump(doc, open(tmp, 'w'), indent=1); os.replace(tmp, RUNS / 'lanes.json')
    except Exception:
        pass


# ------------------------------------------------------------------ 3. watch them
t0 = time.time(); winner = None
try:
    while any(pr.poll() is None for pr in procs):
        time.sleep(30)
        rows, best, best_ret = [], names[0], -math.inf
        for n in names:
            st = status(n); ev = (st.get('evals') or [{}])[-1]
            ret = st.get('best_eval_return')
            if ret is not None and ret > best_ret: best, best_ret = n, ret
            rows.append(f"  {n:10s} {varof[n]:8s} {st.get('steps', 0):>11,} st  {st.get('steps_per_s', 0):5.0f} st/s  "
                        f"eval ret {ev.get('ep_return', float('nan')):7.1f}  up {100 * ev.get('upright_frac', 0):3.0f}%  "
                        f"hold {ev.get('best_hold_s', 0):4.1f}s  v {ev.get('max_cart_v', 0):4.2f}  "
                        f"acc {ev.get('max_cart_a', 0):3.0f}  best {ret if ret is not None else float('nan'):7.1f}  "
                        f"{st.get('phase', 'starting')}")
            if st.get('phase') == 'solved' and winner is None:
                winner = n
        total = sum(status(n).get('steps_per_s', 0) for n in names)
        print(f"[{time.strftime('%H:%M:%S')}  {(time.time() - t0) / 3600:.2f} h  total {total:.0f} st/s]", flush=True)
        print('\n'.join(rows), flush=True)
        write_lanes(best)
        if winner:
            print(f'SOLVED by {winner}. Stopping the other runs...', flush=True)
            for n in names:
                if n != winner: (RUNS / n / 'STOP').touch()
            for pr in procs:
                try: pr.wait(timeout=600)
                except Exception: pr.terminate()
            break
except KeyboardInterrupt:
    print('Pausing... each run saves its policy, replay buffer and counters. '
          f'Continue later with:  python turbo.py --prefix {a.prefix} --resume', flush=True)
    for n in names: (RUNS / n / 'STOP').touch()
    t_end = time.time() + 60
    while any(pr.poll() is None for pr in procs) and time.time() < t_end:
        try: time.sleep(0.5)
        except KeyboardInterrupt: break

print('\nResults:')
for n in names:
    st = status(n)
    print(f"  {n}: {st.get('phase')}, {st.get('steps', 0):,} steps, best eval return {st.get('best_eval_return')}"
          f"   -> runs/{n}/best.zip")
if winner:
    print(f'Watch it:  python watch.py --run {winner} --policy best')
