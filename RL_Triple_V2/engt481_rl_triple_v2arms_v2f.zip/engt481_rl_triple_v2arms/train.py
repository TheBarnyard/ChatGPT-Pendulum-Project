"""
Train a policy for the ENGT481 cart triple (or double) pendulum.

  python train.py --task triple_balance
  python train.py --task triple_swingup --init-from runs/<triple_balance run>/best.zip

  python train.py --task double_balance                 # SAC, the better version's settings
  python train.py --task double_swingup --dashboard
  python train.py --task double_swingup --init-from runs/<double_balance run>/best.zip

What you get in runs/<task>-<timestamp>/ :
  status.json, metrics.csv   live progress (read by dashboard.py)
  latest.zip, best.zip       policies (latest = newest, best = highest eval score)
  checkpoints/step_*.zip     one per evaluation
  videos/step_*.mp4          evaluation rollout video at each evaluation
  trace/step_*.csv.gz        100 Hz trace of each eval's first episode (diagnostics)
  diag.jsonl                 learner health per eval / snapshot
  tb/                        TensorBoard logs  (tensorboard --logdir runs)

Training numbers (learner, reward, starts, pass test) are the "BETTER TRAINING NUMBERS AND RESULT"
version's. Program features (ETAs, diagnostics, report, lanes, video per eval) are from v4.1.
Auto-stop: double_balance after 3 passing evals in a row, double_swingup after 5.
"""
import argparse, csv, json, os, shutil, sys, time, subprocess, webbrowser
from collections import deque
from datetime import datetime
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parent
os.environ.setdefault('MUJOCO_GL', 'egl' if sys.platform.startswith('linux') else 'glfw')

from pendulum_env import CartPendulumEnv, make_env, TASKS, ENV_VERSION
import diagnostics
from stable_baselines3 import SAC, PPO
from stable_baselines3.common.callbacks import BaseCallback
from stable_baselines3.common.vec_env import DummyVecEnv, SubprocVecEnv

# upper limits; auto-stop ends each task when solved. The swing-up budget is large so it keeps
# going until it gets its 5 passes in a row (Ctrl+C any time; latest.zip / best.zip are kept).
DEFAULT_STEPS = {'double_balance': 600_000, 'double_swingup': 10_000_000,
                 'triple_balance': 3_000_000, 'triple_swingup': 60_000_000}
DEFAULT_PATIENCE = {'double_balance': 3, 'double_swingup': 5, 'triple_balance': 3, 'triple_swingup': 5}   # passing evals in a row to stop
HISTORY = ROOT / 'runs' / 'solve_history.json'


def fitprint(s):
    w = shutil.get_terminal_size((120, 20)).columns - 1
    print(s if len(s) <= w else s[:w - 1] + '~', flush=True)


def fmt_t(s):
    s = int(max(s, 0)); h, r = divmod(s, 3600); m, s = divmod(r, 60)
    return f'{h:d}:{m:02d}:{s:02d}'


def safe_replace(src, dst, tries=40):
    """os.replace that tolerates Windows file locks (the dashboard or watch.py reading the file)."""
    for i in range(tries):
        try:
            os.replace(src, dst); return True
        except PermissionError:
            time.sleep(0.25)
    try: os.remove(src)
    except OSError: pass
    print(f'  (could not update {Path(dst).name}: file in use; will retry next save)', flush=True)
    return False


def atomic_json(path, obj):
    tmp = str(path) + '.tmp'
    with open(tmp, 'w') as f: json.dump(obj, f, indent=1)
    safe_replace(tmp, path)


def evaluate(policy, task, env_cfg, n_episodes, video_path=None, label='', seed=10_000, trace_path=None):
    """Deterministic rollouts from the task's start pose. Records episode 0 to mp4 and, step by step,
    to a trace file (runs/<run>/trace/) that diagnostics.py / report.py analyse."""
    env = CartPendulumEnv(task, **env_cfg)
    results, frames, rows = [], [], []
    for ep in range(n_episodes):
        obs, _ = env.reset(seed=seed + ep)
        done = False
        while not done:
            act, _ = policy.predict(obs, deterministic=True)
            obs, r, term, trunc, info = env.step(act)
            done = term or trunc
            if ep == 0: rows.append(diagnostics.trace_row(env, act))
            if video_path and ep == 0 and env.steps % 2 == 0:          # 50 fps video
                th, _ = env.angles()
                hud = [label, f't {env.steps*0.01:5.2f} s   x {env.data.qpos[0]*1000:+6.0f} mm',
                       'theta ' + '  '.join(f'{np.degrees((a+np.pi)%(2*np.pi)-np.pi):+7.1f}' for a in th) + ' deg',
                       f'return {env.ep_return:7.1f}   hold {env.hold*0.01:4.1f} s', env.cart_hud()]
                try:
                    frames.append(env.render(hud))
                except Exception as e:
                    print(f'  [video disabled: {e}]'); video_path = None; frames = []
        results.append(info)
    env.close()
    if video_path and frames:
        import imageio.v2 as imageio
        tmp = str(video_path).replace('.mp4', '.tmp.mp4')
        imageio.mimsave(tmp, frames, fps=50, macro_block_size=1, quality=7)
        safe_replace(tmp, video_path)
    keys = ['ep_return', 'upright_frac', 'best_hold_s', 'ep_steps']
    out = {k: float(np.mean([r[k] for r in results])) for k in keys}
    out['ends'] = [r['end'] for r in results]
    out['max_arm_w'] = float(max(r.get('max_arm_w', 0) for r in results))
    out['max_cart_v'] = float(max(r.get('max_cart_v', 0) for r in results))
    out['max_cart_a'] = float(max(r.get('max_cart_a', 0) for r in results))
    out['max_near_w'] = float(max(r.get('max_near_w', 0) for r in results))
    out['max_loops'] = float(max(r.get('max_loops', 0) for r in results))
    out['max_jolts'] = float(max(r.get('max_jolts', 0) for r in results))
    header = diagnostics.trace_header(env.n_arms)
    try:
        out['diag'] = diagnostics.analyse(header, np.array(rows), task, results[0]['end'])
        if trace_path: diagnostics.save_trace(trace_path, header, rows)
    except Exception as e:
        out['diag'] = dict(flags=[f'diagnostics failed: {e}'])
    return out


class Capture:
    """SB3 logger output that keeps the latest training numbers (losses, entropy coefficient...)."""
    def __init__(self): self.v = {}
    def write(self, kv, key_excluded, step=0):
        for k, x in kv.items():
            if isinstance(x, (int, float, np.floating, np.integer)): self.v[k] = float(x)
    def close(self): pass


def is_solved(task, ev):
    """All eval episodes ran the full time and held upright long enough."""
    if any(e != 'time' for e in ev['ends']):
        return False
    secs = TASKS[task]['seconds']
    if task.endswith('balance'):
        return ev['upright_frac'] >= 0.95
    T = TASKS[task]
    return (ev['best_hold_s'] >= secs - T.get('swing_s', 4.0)      # swing up within swing_s, then hold
            and ev['upright_frac'] >= T.get('pass_up_frac', 0.55))


def load_history(task, model):
    """Steps-to-solve from earlier runs of this task on the same model (hardware independent)."""
    try:
        h = json.load(open(HISTORY))
        return [r['steps'] for r in h.get(task, []) if r.get('model', 'model') == model]
    except Exception:
        return []


def save_history(task, model, steps, run):
    try: h = json.load(open(HISTORY))
    except Exception: h = {}
    h.setdefault(task, []).append(dict(steps=int(steps), model=model, run=run, date=datetime.now().isoformat(timespec='minutes')))
    HISTORY.parent.mkdir(exist_ok=True); atomic_json(HISTORY, h)


class LiveCallback(BaseCallback):
    def __init__(self, run, args, env_cfg, resume=None):
        super().__init__()
        self.run, self.a, self.env_cfg = run, args, env_cfg
        self.recent = deque(maxlen=50)
        self.t0 = time.time(); self.last_print = 0; self.next_eval = 0; self.next_latest = 0
        self.best = -np.inf; self.history = []
        self.streak = 0; self.solved_at = None; self.episodes0 = 0
        if resume:                                    # continue the counters of a paused run
            self.t0 = time.time() - resume.get('elapsed_s', 0)
            self.next_eval, self.next_latest = resume.get('next_eval', 0), resume.get('next_latest', 0)
            self.best = resume['best'] if resume.get('best') is not None else -np.inf
            self.streak, self.episodes0 = resume.get('streak', 0), resume.get('episodes', 0)
            try: self.history = json.load(open(run / 'status.json')).get('evals', [])
            except Exception: pass
        new_csv = not (resume and (run / 'metrics.csv').exists())
        self.csv = open(run / 'metrics.csv', 'w' if new_csv else 'a', newline='')
        self.w = csv.writer(self.csv)
        if new_csv:
            self.w.writerow(['steps', 'elapsed_s', 'eval_return', 'eval_upright_frac', 'eval_best_hold_s',
                             'train_return', 'train_upright_frac', 'video'])
        self.phase = 'starting'
        self.samples = deque(); self.hist = load_history(args.task, env_cfg.get('model', 'model') + '-' + ENV_VERSION)
        self.video_proc = None; self.video_procs = []

    def speed(self):
        """Steps/s over the last ~60 s (the all-time average is skewed by the fast warm-up)."""
        now, steps = time.time(), self.num_timesteps
        self.samples.append((now, steps))
        while len(self.samples) > 2 and now - self.samples[0][0] > 60: self.samples.popleft()
        (t0, s0) = self.samples[0]
        return (steps - s0) / (now - t0) if now - t0 > 1 else 0.0

    def likely_eta(self, sps):
        """Best guess at time-to-solve (None if there is nothing to base it on).
        - passing evals already: the remaining evals are all that's left (accurate)
        - otherwise: median steps-to-solve of earlier runs of this task, if any"""
        if not self.a.patience or sps <= 0: return None, ''
        steps, E = self.num_timesteps, self.a.eval_every
        if self.streak > 0:
            rem = (self.next_eval - steps) + (self.a.patience - self.streak - 1) * E
            return max(rem, 0) / sps, f'{self.streak}/{self.a.patience} passes'
        hist = self.hist
        if not hist: return None, 'no earlier runs'
        med = float(np.median(hist))
        if steps > 1.5 * max(hist):
            return None, 'slower than earlier runs'
        # earlier runs first passed around (median - (patience-1) evals); from there it needs 'patience' passes
        first_pass = max(np.ceil(med / E) * E - (self.a.patience - 1) * E, self.next_eval)
        target = first_pass + (self.a.patience - 1) * E
        return (target - steps) / sps, f'median of {len(hist)} earlier run' + ('s' if len(hist) > 1 else '')

    def status(self, extra=None):
        steps = self.num_timesteps; el = time.time() - self.t0
        sps = self.speed()
        likely, basis = self.likely_eta(sps)
        st = dict(task=self.a.task, algo=self.a.algo, run=self.run.name, phase=self.phase,
                  steps=steps, total_steps=self.a.steps, elapsed_s=el, steps_per_s=sps,
                  eta_s=(self.a.steps - steps) / sps if sps > 0 else None,
                  eta_likely_s=likely, eta_likely_basis=basis, pass_streak=self.streak, patience=self.a.patience,
                  train_return=float(np.mean([r['ep_return'] for r in self.recent])) if self.recent else None,
                  train_upright_frac=float(np.mean([r['upright_frac'] for r in self.recent])) if self.recent else None,
                  episodes=self.episodes, best_eval_return=None if self.best == -np.inf else self.best,
                  evals=self.history, updated=time.time(), pid=os.getpid())
        if extra: st.update(extra)
        atomic_json(self.run / 'status.json', st)
        return st

    def _on_training_start(self):
        self.episodes = self.episodes0; self.phase = 'training'; self.status()

    def _on_step(self):
        for info in self.locals.get('infos', []):
            if 'ep_return' in info:
                self.recent.append(info); self.episodes += 1
        now = time.time()
        if now - self.last_print > self.a.print_every:
            self.last_print = now
            st = self.status()
            pct = 100 * st['steps'] / st['total_steps']
            tr = f"{st['train_return']:.0f}" if st['train_return'] is not None else '--'
            up = f"{100*st['train_upright_frac']:.0f}%" if st['train_upright_frac'] is not None else '--'
            eta = fmt_t(st['eta_s']) if st['eta_s'] else '--:--:--'
            lik = fmt_t(st['eta_likely_s']) if st['eta_likely_s'] is not None else '--'
            # fields in priority order; the lowest-priority ones are dropped so the line
            # always fits the current window width (one line per update, never wrapped)
            fields = [f"{pct:5.1f}%", f"{st['steps']:,}/{st['total_steps']:,}", f"{st['steps_per_s']:.0f} st/s",
                      f"ETA {lik}", f"max {eta}", f"ret {tr}", f"up {up}", f"ep {self.episodes}"]
            width = shutil.get_terminal_size((120, 20)).columns - 1
            while len('  '.join(fields)) > width and len(fields) > 3:
                fields.pop()
            line = '  '.join(fields)
            room = width - len(line) - 3
            if room >= 10:                                      # progress bar gets whatever space is left
                n = min(room, 30); k = int(n * pct / 100)
                line = '[' + '#' * k + '-' * (n - k) + '] ' + line
            print(line[:width], flush=True)
        if now - getattr(self, '_stop_chk', 0) > 5:            # turbo.py asks a run to stop with runs/<run>/STOP
            self._stop_chk = now
            if (self.run / 'STOP').exists():
                fitprint('  STOP file found: saving (resumable) and stopping.')
                save_resume(self.model, self, self.run); self.paused = True; return False
        if self.num_timesteps >= self.next_latest:
            self.next_latest += self.a.latest_every
            self.save_latest(); self.log_diag('snapshot')
        if self.num_timesteps >= self.next_eval:
            self.next_eval += self.a.eval_every
            self.do_eval()
            if self.a.patience and self.streak >= self.a.patience:
                self.solved_at = self.num_timesteps
                save_history(self.a.task, self.env_cfg.get('model', 'model') + '-' + ENV_VERSION, self.num_timesteps, self.run.name)
                fitprint(f"  SOLVED at {self.num_timesteps:,} steps ({fmt_t(time.time() - self.t0)}), "
                         f"{self.streak} passes in a row. Stopping this task.")
                return False
        return True

    def log_diag(self, kind, ev=None):
        """One JSON line per eval / snapshot: what the learner and the training episodes looked like."""
        rec = dict(kind=kind, steps=self.num_timesteps, t=round(time.time() - self.t0, 1), sps=round(self.speed(), 1))
        try:
            ent = getattr(self.model, 'log_ent_coef', None)
            if ent is not None: rec['ent_coef'] = round(float(ent.detach().exp().item()), 5)
            cap = getattr(self, 'capture', None)
            if cap: rec['sb3'] = {k: round(v, 5) for k, v in cap.v.items() if k.startswith('train/')}
        except Exception:
            pass
        R = list(self.recent)
        if R:
            ends = {}
            for r in R: ends[r['end']] = ends.get(r['end'], 0) + 1
            rec['train_eps'] = dict(n=len(R), ends=ends,
                                    ret=round(float(np.mean([r['ep_return'] for r in R])), 1),
                                    upright=round(float(np.mean([r['upright_frac'] for r in R])), 3),
                                    jolts=round(float(np.mean([r.get('max_jolts', 0) for r in R])), 1),
                                    loops=round(float(np.mean([r.get('max_loops', 0) for r in R])), 2),
                                    cart_v=round(float(np.mean([r.get('max_cart_v', 0) for r in R])), 2),
                                    cart_a=round(float(np.mean([r.get('max_cart_a', 0) for r in R])), 1))
        if ev is not None:
            rec['eval'] = {k: ev[k] for k in ('ep_return', 'upright_frac', 'best_hold_s', 'ends')}
            rec['diag'] = ev.get('diag')
        try:
            with open(self.run / 'diag.jsonl', 'a') as f: f.write(json.dumps(rec) + '\n')
        except Exception:
            pass

    def save_latest(self):
        # frequent snapshot for the live viewers (watch.py / dashboard)
        tmp = self.run / 'latest.tmp.zip'; self.model.save(tmp); safe_replace(tmp, self.run / 'latest.zip')
        atomic_json(self.run / 'latest.json', dict(steps=self.num_timesteps, time=time.time()))

    def do_eval(self):
        self.phase = 'evaluating'; self.status()
        step = self.num_timesteps
        ck = self.run / 'checkpoints' / f'step_{step:09d}.zip'
        self.model.save(ck)
        self.save_latest()
        t = time.time()
        (self.run / 'trace').mkdir(exist_ok=True)
        ev = evaluate(self.model, self.a.task, self.env_cfg, self.a.eval_episodes,
                      trace_path=self.run / 'trace' / f'step_{step:09d}.csv.gz')
        self.log_diag('eval', ev)
        new_best = ev['ep_return'] > self.best
        if new_best:
            self.best = ev['ep_return']
            tmp = self.run / 'best.tmp.zip'; self.model.save(tmp); safe_replace(tmp, self.run / 'best.zip')
        vid = None
        if not self.a.no_video:
            # every eval gets a video (the dashboard shows the newest one per lane)
            if True:
                vid = self.run / 'videos' / f'step_{step:09d}.mp4'
                # render in a separate process so training never waits on video encoding
                self.video_proc = subprocess.Popen(
                    [sys.executable, str(ROOT / 'record.py'), '--run', str(self.run), '--policy', str(ck),
                     '--out', str(vid), '--seconds', str(TASKS[self.a.task]['seconds']),
                     '--width', '854', '--height', '480', '--seed', '10000',
                     '--label', f'{self.a.task}  {self.a.algo.upper()}  step {step:,}' + ('  (best)' if new_best else '')],
                    stdout=subprocess.DEVNULL, stderr=open(self.run / 'render.log', 'a'))
                self.video_procs.append(self.video_proc)
        row = dict(steps=step, elapsed_s=time.time() - self.t0, **ev,
                   video=vid.name if vid else None, best=new_best)
        tr = [float(np.mean([r[k] for r in self.recent])) if self.recent else float('nan')
              for k in ('ep_return', 'upright_frac')]
        row['train_return'] = tr[0] if self.recent else None
        row['passed'] = is_solved(self.a.task, ev)
        self.streak = self.streak + 1 if row['passed'] else 0
        row['streak'] = self.streak
        self.history.append(row)
        self.w.writerow([step, round(row['elapsed_s'], 1), round(ev['ep_return'], 2), round(ev['upright_frac'], 4),
                         round(ev['best_hold_s'], 2), round(tr[0], 2), round(tr[1], 4), row['video'] or ''])
        self.csv.flush()
        ends = ','.join(e[0] for e in ev['ends'])            # t=time, f=fell, r=rail, s=stall (over speed)
        tags = (f"PASS {self.streak}/{self.a.patience} " if row['passed'] and self.a.patience else '') \
               + ('BEST ' if new_best else '')
        fitprint(f"  eval @ {step:,}: {tags}return {ev['ep_return']:.1f}  upright {100*ev['upright_frac']:.0f}%  "
                 f"hold {ev['best_hold_s']:.1f}s  ends {ends}  arm max {ev['max_arm_w']:.1f} rad/s  loops {ev['max_loops']:.1f}/3s  jolts {ev['max_jolts']:.0f}/s  cart max {ev['max_cart_v']:.2f} m/s  acc max {ev.get('max_cart_a', 0):.0f} m/s^2")
        fitprint(f"    behaviour: {diagnostics.one_line(ev.get('diag', {}))}")
        self.phase = 'training'; self.status()

    def _on_training_end(self):
        if getattr(self, 'paused', False):
            self.phase = 'paused'; self.status(); self.csv.close(); return
        if self.solved_at is None and (not self.history or self.history[-1]['steps'] != self.num_timesteps):
            for pr in self.video_procs: pr.wait()
            self.do_eval()          # final eval, unless one just ran at this step (it would count a pass twice)
        for pr in self.video_procs: pr.wait()
        self.phase = 'solved' if self.solved_at else 'done'
        self.status(dict(solved_at=self.solved_at)); self.csv.close()


GAMMA = 0.99


def save_resume(model, cb, run):
    """Everything needed to continue exactly: policy + optimisers + entropy coef (latest.zip), the replay
    buffer (replay_buffer.pkl) and the trainer's counters (resume.json). python train.py --resume <run>"""
    tmp = run / 'latest.tmp.zip'; model.save(tmp); safe_replace(tmp, run / 'latest.zip')
    if hasattr(model, 'save_replay_buffer'):
        try:
            model.save_replay_buffer(run / 'replay_buffer.tmp.pkl')
            safe_replace(run / 'replay_buffer.tmp.pkl', run / 'replay_buffer.pkl')
        except Exception as e:
            print(f'(replay buffer not saved: {e})')
    atomic_json(run / 'resume.json', dict(steps=int(model.num_timesteps), best=None if cb.best == -np.inf else cb.best,
                                          streak=cb.streak, next_eval=cb.next_eval, next_latest=cb.next_latest,
                                          elapsed_s=time.time() - cb.t0, episodes=getattr(cb, 'episodes', 0),
                                          time=time.time()))
    print(f'Saved for resume at step {model.num_timesteps:,}:  python train.py --resume {run.name}', flush=True)


def build_model(algo, venv, device, gradient_steps, batch_size, seed=0, tb=None, learning_starts=5_000):
    """Learner settings of the better version (plain SAC, 256x256, lr 3e-4, tau 0.005)."""
    if algo == 'sac':
        return SAC('MlpPolicy', venv, learning_rate=3e-4, buffer_size=1_000_000, batch_size=batch_size,
                   gamma=GAMMA, tau=0.005, learning_starts=learning_starts, train_freq=1,
                   gradient_steps=gradient_steps, policy_kwargs=dict(net_arch=[256, 256]), seed=seed,
                   device=device, tensorboard_log=tb, verbose=0)
    return PPO('MlpPolicy', venv, n_steps=2048, batch_size=max(batch_size, 512), n_epochs=10, gamma=0.995,
               gae_lambda=0.95, learning_rate=3e-4, clip_range=0.2, ent_coef=0.0,
               policy_kwargs=dict(net_arch=dict(pi=[128, 128], vf=[256, 256])),
               seed=seed, device=device, tensorboard_log=tb, verbose=0)


def benchmark(task='double_swingup', envs=8, gradient_steps=8, batch_size=512, devices=None, quiet=False, algo='sac'):
    """Time training steps of the real learner on each device (about 30 s each). Returns {device: steps/s}."""
    import torch
    devices = devices or (['cpu', 'cuda'] if torch.cuda.is_available() else ['cpu'])
    venv = DummyVecEnv([make_env(task, i, 0, train_mode=True) for i in range(envs)])
    res = {}
    for dev in devices:
        m = build_model(algo, venv, dev, gradient_steps, batch_size, learning_starts=1000)
        class T(BaseCallback):
            def _on_step(s):
                if s.num_timesteps >= 1000 and not hasattr(s, 't0'): s.t0 = time.time(); s.n0 = s.num_timesteps
                return True
        cb = T(); m.learn(total_timesteps=1000 + 150 * envs * 4, callback=cb)
        res[dev] = (cb.num_timesteps - cb.n0) / (time.time() - cb.t0)
        if not quiet: print(f'  {dev}: {res[dev]:.0f} steps/s', flush=True)
        del m
    venv.close()
    return res


def pick_device(a, venv):
    """Benchmark CPU vs GPU with this run's settings every time (no cache) and use the faster one."""
    import torch
    if a.algo == 'ppo' or not torch.cuda.is_available():
        return 'cpu'
    print('Benchmarking CPU vs GPU (about a minute)...', flush=True)
    res = benchmark(a.task, a.envs, a.gradient_steps, a.batch_size, algo=a.algo)
    best = max(res, key=res.get)
    print(f'Device: {best}', flush=True)
    return best


def _stop(*_):
    raise KeyboardInterrupt


def main():
    import signal
    signal.signal(signal.SIGINT, signal.default_int_handler)
    try: signal.signal(signal.SIGTERM, _stop)
    except Exception: pass
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--task', default='triple_balance', choices=list(TASKS))
    p.add_argument('--algo', default='sac', choices=['sac', 'ppo'])
    p.add_argument('--steps', type=int, default=None, help='total control steps (100 per sim-second)')
    p.add_argument('--envs', type=int, default=None, help='parallel envs (SAC 1-4, PPO 8-16)')
    p.add_argument('--eval-every', type=int, default=None)
    p.add_argument('--eval-episodes', type=int, default=3)
    p.add_argument('--max-speed', type=float, default=None, help='cart speed limit m/s (default 1.4)')
    p.add_argument('--max-accel', type=float, default=None, help='accel mode only: cart acceleration limit m/s^2 (default 20)')
    p.add_argument('--rail-limit', type=float, default=None, help='episode ends past this |x| (default 0.50 m)')
    p.add_argument('--randomize', action='store_true', help='mass/gain/latency/noise randomisation (sim2real)')
    p.add_argument('--upright-start-prob', type=float, default=None,
                   help='swing-up: fraction of training episodes started upright, to practise the catch (default 0.1)')
    p.add_argument('--action-mode', default='velocity', choices=['velocity', 'accel'],
                   help='velocity (default, the better version): policy sets cart speed; accel: v4.1 acceleration mode')
    p.add_argument('--threads', type=int, default=None, help='torch CPU threads (run_all splits the cores per lane)')
    p.add_argument('--init-from', default=None, help='start from an existing .zip policy (same algo & obs size)')
    p.add_argument('--seed', type=int, default=0)
    p.add_argument('--model', default='model', help="model folder (default 'model' = corrected new arms)")
    p.add_argument('--patience', type=int, default=None,
                   help='stop after this many passing evals in a row (default 3 balance, 5 swing-up; 0 = never)')
    p.add_argument('--gradient-steps', type=int, default=None,
                   help='SAC: network updates per env step-batch (use ~envs/2 with --envs 8+)')
    p.add_argument('--batch-size', type=int, default=None, help='minibatch size (default 512)')
    p.add_argument('--reward', default=None, choices=['plain', 'height', 'energy'],
                   help="override the task's reward (triple_swingup default: energy)")
    p.add_argument('--spin-penalty', type=float, default=None, help='anti fan-blading penalty per rad/s over 25 (e.g. 0.01)')
    p.add_argument('--explore-start-prob', type=float, default=None, help='share of random-pose training starts')
    p.add_argument('--resume', default=None, help='continue a paused run exactly (run folder name)')
    p.add_argument('--cart-accel-limit', type=float, default=None, help='cap the cart acceleration, m/s^2 (e.g. 18)')
    p.add_argument('--smooth-reward', action='store_true', default=None,
                   help='reward gentle, smooth cart acceleration (multiplicative, cannot make standing still pay)')
    p.add_argument('--ent-coef-init', type=float, default=None,
                   help='with --init-from: reset SAC exploration (entropy coef) to this; default 0.1 for swing-up')
    p.add_argument('--name', default=None)
    p.add_argument('--print-every', type=float, default=5.0, help='seconds between progress lines')
    p.add_argument('--device', default='auto', help='cpu / cuda / auto (auto = quick benchmark, cached)')
    p.add_argument('--no-video', action='store_true')
    p.add_argument('--dashboard', action='store_true', help='also start the browser dashboard')
    p.add_argument('--watch', action='store_true', help='also open the live MuJoCo window')
    a = p.parse_args()
    resume = None
    if a.resume:
        rdir = Path(a.resume) if Path(a.resume).is_dir() else ROOT / 'runs' / a.resume
        if not (rdir / 'latest.zip').exists():
            raise SystemExit(f'Nothing to resume in {rdir} (no latest.zip)')
        saved = json.load(open(rdir / 'config.json'))
        cli_device = a.device
        for k, v in saved.items():
            if k in ('env_cfg', 'resume', 'print_every', 'dashboard', 'watch', 'threads', 'device'): continue
            setattr(a, k, v)
        a.device = cli_device if cli_device != 'auto' else saved.get('device', 'auto')
        a.name, a.init_from = rdir.name, None
        try: resume = json.load(open(rdir / 'resume.json'))
        except Exception: resume = {}

    a.steps = a.steps or DEFAULT_STEPS[a.task]
    a.patience = DEFAULT_PATIENCE[a.task] if a.patience is None else a.patience
    a.envs = a.envs or 8
    # updates per collected transition: 0.5 is plenty for balance; the double swing-up
    # learned noticeably slower at 0.5 in testing, so it keeps 1.0
    hard = a.task.endswith('swingup')
    a.gradient_steps = a.gradient_steps or (a.envs if hard else max(1, a.envs // 2))
    a.batch_size = a.batch_size or 512
    a.eval_every = a.eval_every or (50_000 if a.task == 'triple_swingup' else 20_000 if hard else 10_000)
    a.latest_every = max(5_000, a.eval_every // 2)
    if a.upright_start_prob is None and a.task.endswith('swingup'):
        a.upright_start_prob = 0.1
    env_cfg = dict(max_speed=a.max_speed, max_accel=a.max_accel, rail_limit=a.rail_limit, randomize=a.randomize,
                   upright_start_prob=a.upright_start_prob, model=a.model, action_mode=a.action_mode,
                   reward=a.reward, spin_penalty=a.spin_penalty, explore_start_prob=a.explore_start_prob,
                   cart_accel_limit=a.cart_accel_limit, smooth_reward=a.smooth_reward)
    env_cfg = {k: v for k, v in env_cfg.items() if v is not None}

    name = a.name or f"{a.task}-{a.algo}-{datetime.now():%Y%m%d-%H%M%S}"
    run = ROOT / 'runs' / name
    (run / 'checkpoints').mkdir(parents=True, exist_ok=True); (run / 'videos').mkdir(exist_ok=True)
    if not a.resume:
        json.dump(dict(vars(a), env_cfg=env_cfg), open(run / 'config.json', 'w'), indent=1)
    (ROOT / 'runs' / 'LATEST').write_text(name)
    print(f'Run folder: {run}')
    print(f'Task {a.task}  algo {a.algo}  max {a.steps:,} steps  envs {a.envs}  gradient steps {a.gradient_steps}  '
          f'batch {a.batch_size}  ' + (f'auto-stop after {a.patience} passing evals' if a.patience else 'no auto-stop'))

    procs = []
    if a.dashboard:
        procs.append(subprocess.Popen([sys.executable, str(ROOT / 'dashboard.py'), '--no-browser']))
        time.sleep(1.5); webbrowser.open('http://localhost:8000')
    if a.watch:
        procs.append(subprocess.Popen([sys.executable, str(ROOT / 'watch.py'), '--run', str(run)]))

    fns = [make_env(a.task, i, a.seed, train_mode=True, **env_cfg) for i in range(a.envs)]
    use_sub = a.algo == 'ppo' and a.envs >= 4 and (os.cpu_count() or 1) >= 4   # SAC: envs are cheap, keep in-process
    venv = SubprocVecEnv(fns) if use_sub else DummyVecEnv(fns)

    import torch
    torch.set_num_threads(a.threads or max(1, min(6, (os.cpu_count() or 2) // 2)))
    if a.device == 'auto':
        a.device = pick_device(a, venv)
    try:
        import tensorboard  # noqa: F401
        tb = str(run / 'tb')
    except ImportError:
        tb = None
    if a.resume:
        Algo = SAC if a.algo == 'sac' else PPO
        extra = dict(gradient_steps=a.gradient_steps, batch_size=a.batch_size) if a.algo == 'sac' else {}
        model = Algo.load(run / 'latest.zip', env=venv, device=a.device, tensorboard_log=tb, custom_objects=extra)
        rb = run / 'replay_buffer.pkl'
        if a.algo == 'sac' and rb.exists():
            model.load_replay_buffer(rb)
            print(f'Resumed {run.name} at step {model.num_timesteps:,} with its replay buffer '
                  f'({model.replay_buffer.size() * a.envs:,} transitions)')
        else:
            if a.algo == 'sac':        # no buffer saved (older version): refill before learning again
                model.learning_starts = model.num_timesteps + max(20_000, 2 * a.batch_size)
            print(f'Resumed {run.name} at step {model.num_timesteps:,} (no replay buffer saved; refilling 20k steps first)')
    elif a.init_from:
        Algo = SAC if a.algo == 'sac' else PPO
        extra = dict(gradient_steps=a.gradient_steps, batch_size=a.batch_size) if a.algo == 'sac' else {}
        model = Algo.load(a.init_from, env=venv, device=a.device, tensorboard_log=tb, custom_objects=extra)
        print(f'Initialised from {a.init_from}')
        ent0 = a.ent_coef_init if a.ent_coef_init is not None else (0.1 if a.task.endswith('swingup') else None)
        if ent0 and getattr(model, 'log_ent_coef', None) is not None:
            import math
            with torch.no_grad():
                model.log_ent_coef.fill_(math.log(ent0))
            print(f'Exploration reset: entropy coef {ent0} (the balance policy had almost none left)')
    else:
        model = build_model(a.algo, venv, a.device, a.gradient_steps, a.batch_size, a.seed, tb)

    cb = LiveCallback(run, a, env_cfg, resume=resume if a.resume else None)
    try:
        from stable_baselines3.common.logger import Logger, TensorBoardOutputFormat
        cb.capture = Capture()
        outs = [cb.capture] + ([TensorBoardOutputFormat(str(run / 'tb'))] if tb else [])
        model.set_logger(Logger(None, outs))
    except Exception as e:
        print(f'(training-stat capture disabled: {e})')
    try:
        if a.resume:
            model.learn(total_timesteps=max(1, a.steps - model.num_timesteps), callback=cb, tb_log_name='tb',
                        progress_bar=False, reset_num_timesteps=False)
        else:
            model.learn(total_timesteps=a.steps, callback=cb, tb_log_name='tb', progress_bar=False)
    except KeyboardInterrupt:
        print('\nStopped by user; saving (resumable)...', flush=True)
        save_resume(model, cb, run); cb.phase = 'paused'; cb.status()
    venv.close()
    print(f'\nDone. Best eval return {cb.best:.1f}.  Policies: {run / "best.zip"}')
    print(f'Replay: python watch.py --run {run.name}     Video: python record.py --run {run.name}')
    for pr in procs:
        print('Dashboard / viewer still running; close it with Ctrl+C or its window.') if pr.poll() is None else None


if __name__ == '__main__':
    main()
