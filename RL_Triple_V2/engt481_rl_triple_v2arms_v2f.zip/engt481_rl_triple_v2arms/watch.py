"""
Live MuJoCo window that plays the policy while it trains.

  python watch.py                      # newest run, reloads latest.zip whenever training saves one
  python watch.py --run <run> --policy best
  python watch.py --task triple_swingup --passive     # no controller, just the physics
  python watch.py --task triple_balance --lqr         # the team-style LQR, for comparison

Mouse: left-drag rotate, right-drag pan, scroll zoom.
Double-click an arm, then Ctrl + right-drag to push it (perturbation test).
Space pauses.  Backspace resets the episode.
"""
import argparse, os, sys, time
import numpy as np
import mujoco, mujoco.viewer

from pendulum_env import CartPendulumEnv, TASKS
from common import resolve_run, run_config, load_policy, policy_step


class LQR:
    """Small-angle LQR (acceleration -> velocity command), any number of arms. Model v3 params only."""
    def __init__(self, env):
        from scipy.linalg import solve_discrete_are, expm
        import json
        P = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), env.cfg['model'], 'params.json')))
        arms = P[env.kind]['arms']; n = len(arms); g, Ts = 9.81, 0.01
        m = [a['mass'] for a in arms]; lc = [a['com_along'] for a in arms]; L = [a['length'] for a in arms]
        I = [a['I_swing'] for a in arms]
        a_ = lambda k, i: L[i] if i < k else (lc[i] if i == k else 0)
        M = np.array([[sum(m[k] * a_(k, i) * a_(k, j) for k in range(n)) + (I[i] if i == j else 0)
                       for j in range(n)] for i in range(n)])
        c = np.array([sum(m[k] * a_(k, i) for k in range(n)) for i in range(n)])
        N = 1 + n; A = np.zeros((2 * N, 2 * N)); B = np.zeros((2 * N, 1)); A[:N, N:] = np.eye(N)
        Mi = np.linalg.inv(M); A[N + 1:, 1:N] = Mi @ np.diag(g * c); B[N, 0] = 1; B[N + 1:, 0] = -Mi @ c
        Z = expm(np.block([[A, B], [np.zeros((1, 2 * N + 1))]]) * Ts); Ad, Bd = Z[:2 * N, :2 * N], Z[:2 * N, 2 * N:]
        Q = np.diag([20] + [100] * n + [1] * (n + 1)); R = np.array([[0.1 if n < 3 else 0.05]])
        S = solve_discrete_are(Ad, Bd, Q, R)
        self.K = np.linalg.solve(R + Bd.T @ S @ Bd, Bd.T @ S @ Ad)[0]
        self.env = env; self.v = 0.0

    def predict(self, obs, deterministic=True):
        e = self.env; th, w = e.angles(); th = (th + np.pi) % (2 * np.pi) - np.pi
        s = np.r_[e.data.qpos[0], th, e.data.qvel[0], w]
        u = np.clip(-self.K @ s, -30, 30)
        if getattr(e, 'accel_mode', False):
            return np.array([np.clip(u / e.cfg['max_accel'], -1, 1)]), None
        self.v = np.clip(e.data.qvel[0] + u * 0.01, -e.cfg['max_speed'], e.cfg['max_speed'])
        return np.array([self.v / e.cfg['max_speed']]), None


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--run', default=None)
    p.add_argument('--policy', default='latest', help="latest | best | path to .zip")
    p.add_argument('--task', default=None, help='override task (e.g. test a swing-up policy from upright)')
    p.add_argument('--passive', action='store_true', help='no controller')
    p.add_argument('--lqr', action='store_true', help='use the LQR instead of a learned policy')
    p.add_argument('--speed', type=float, default=1.0, help='playback speed (0.25 = slow motion)')
    a = p.parse_args()

    run_dir, cfg = None, {}
    if not (a.passive or a.lqr):
        run_dir = resolve_run(a.run); cfg = run_config(run_dir)
    task = a.task or cfg.get('task') or 'triple_swingup'
    env = CartPendulumEnv(task, **{k: v for k, v in cfg.get('env_cfg', {}).items() if k != 'upright_start_prob'})
    m, d = env.model, env.data

    policy, mtime, label = None, 0, 'passive'
    if a.lqr:
        policy, label = LQR(env), 'LQR'
    def policy_path():
        if a.policy in ('latest', 'best'):
            return run_dir / f'{a.policy}.zip'
        return __import__('pathlib').Path(a.policy)

    def maybe_reload():
        nonlocal policy, mtime, label
        if run_dir is None: return
        pp = policy_path()
        if pp.exists() and pp.stat().st_mtime > mtime + 1e-6:
            try:
                policy = load_policy(pp, cfg['algo']); mtime = pp.stat().st_mtime
                ps = policy_step(run_dir, pp)
                label = f"{run_dir.name}  [{pp.name}]" + (f"  saved at step {ps:,}" if ps is not None else '')
                print('Loaded', pp, '-', label)
            except Exception as e:
                print('reload failed (will retry):', e)

    maybe_reload()
    if run_dir is not None and policy is None:
        print('Waiting for the first checkpoint (training saves one right after it starts)...')

    obs, _ = env.reset()
    paused = [False]; reset_req = [False]
    def key(k):
        if k == 32: paused[0] = not paused[0]
        if k == 259: reset_req[0] = True
    last_check, ep = time.time(), 1
    with mujoco.viewer.launch_passive(m, d, key_callback=key, show_left_ui=False, show_right_ui=False) as v:
        v.cam.azimuth, v.cam.elevation, v.cam.distance = 90, -8, {1: 1.3, 2: 1.7, 3: 2.2}[env.n_arms]
        v.cam.lookat[:] = [0, -0.08, 0.13]
        while v.is_running():
            t0 = time.time()
            if time.time() - last_check > 2.0:
                last_check = time.time(); maybe_reload()
            if reset_req[0]:
                reset_req[0] = False; obs, _ = env.reset(); ep += 1
            if not paused[0]:
                with v.lock():
                    if policy is not None:
                        act, _ = policy.predict(obs, deterministic=True)
                    else:
                        act = np.zeros(1)
                    obs, r, term, trunc, info = env.step(act)
                if term or trunc:
                    print(f"episode {ep}: return {info['ep_return']:.1f}  upright {100*info['upright_frac']:.0f}%  "
                          f"longest hold {info['best_hold_s']:.1f}s  end={info['end']}")
                    time.sleep(0.6); obs, _ = env.reset(); ep += 1
                    if isinstance(policy, LQR): policy.v = 0.0
            th, _ = env.angles()
            txt = (f"{label}\nepisode {ep}   t = {env.steps*0.01:5.2f} s   return {env.ep_return:7.1f}\n"
                   f"x = {d.qpos[0]*1000:+5.0f} mm   theta = "
                   + '  '.join(f'{np.degrees((t+np.pi)%(2*np.pi)-np.pi):+6.1f}' for t in th)
                   + f" deg   hold {env.hold*0.01:4.1f} s\n" + env.cart_hud())
            try:
                v.set_texts((int(mujoco.mjtFontScale.mjFONTSCALE_150), int(mujoco.mjtGridPos.mjGRID_TOPLEFT), txt, ''))
            except Exception:
                pass
            v.sync()
            dt = env.cfg['ctrl_dt'] / a.speed - (time.time() - t0)
            if dt > 0: time.sleep(dt)


if __name__ == '__main__':
    main()
